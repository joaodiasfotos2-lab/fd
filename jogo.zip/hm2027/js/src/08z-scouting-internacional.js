// Scouting internacional por escolas (2026-10-14, pedido do utilizador: "scouting internacional
// por escolas — Espanha, Itália, Argentina, França… mercados com perfis de escola; os olheiros
// demoram semanas; burocracia de inscrição e adaptação").
// Decisões de desenho confirmadas por ele:
//  - ORIGEM dos jogadores: clubes que já existem no jogo (OK Liga e Serie A1: o olheiro deixa
//    "pistas" = relatórios rápidos sobre jogadores reais) + talentos SEM CLUBE gerados pela escola
//    do país (aparecem na secção "Jogadores livres" do Mercado);
//  - o olheiro demora SEMANAS (14-40 dias conforme o país), custa dinheiro e ocupa uma vaga do
//    departamento de scouting;
//  - quem vem de fora tem BUROCRACIA (dias sem poder jogar à espera da inscrição/certificado
//    internacional/visto) e ADAPTAÇÃO (rendimento reduzido que vai recuperando; menor se já há um
//    compatriota no plantel).
//
// Tudo o que não vem de regulamento é ESTIMATIVA do jogo: perfis de escola, custos, prazos,
// probabilidades, dias de burocracia e de adaptação, penalizações de rendimento. A IA não faz
// missões internacionais (só o utilizador) mas pode contratar os talentos livres depois da
// exclusividade de 14 dias.

const SCINT_PAISES = {
  es: {
    nome: "Espanha", nac: "Espanhola", pais: "es", divisoes: ["ok-liga","ok-liga-plata"], custoMult: 1.0, dias: [14, 21], nivelMin: 0,
    registoDias: [7, 12], adaptDias: 45, adaptPen: 0.03, ovrOff: 0.5,
    escola: "Escola espanhola: formação técnica e de posse de bola, a maior tradição do hóquei em patins.",
    bias: { habilidade: 1, drible: 1, bolasParadas: 1, posicionamento: 1, reflexos: 1 },
    forte: "técnica e bola parada", burocracia: "Pertence à UE: inscrição rápida.",
  },
  it: {
    nome: "Itália", nac: "Italiana", pais: "it", divisoes: ["serie-a1"], custoMult: 1.0, dias: [14, 21], nivelMin: 0,
    registoDias: [7, 12], adaptDias: 45, adaptPen: 0.03, ovrOff: 0.5,
    escola: "Escola italiana: rigor tático e defensivo, jogadores disciplinados e competitivos.",
    bias: { posicionamento: 1, desarme: 1, determinacao: 1, finalizacao: 1, umParaUm: 1, concentracao: 1 },
    forte: "tática e disciplina", burocracia: "Pertence à UE: inscrição rápida.",
  },
  fr: {
    nome: "França", nac: "Francesa", pais: "fr", divisoes: [], custoMult: 1.1, dias: [18, 24], nivelMin: 0,
    registoDias: [8, 14], adaptDias: 60, adaptPen: 0.04, ovrOff: -0.5,
    escola: "Escola francesa: formação atlética num mercado ainda pouco explorado.",
    bias: { forca: 1, resistencia: 1, velocidade: 1, aceleracao: 1 },
    forte: "capacidade atlética", burocracia: "Pertence à UE: inscrição rápida.",
  },
  ar: {
    nome: "Argentina", nac: "Argentina", pais: "pt", divisoes: [], custoMult: 1.8, dias: [28, 35], nivelMin: 1,
    registoDias: [20, 32], adaptDias: 90, adaptPen: 0.06, ovrOff: 0,
    escola: "Escola argentina: talento técnico e criativo, com muito carácter dentro de pista.",
    bias: { criatividade: 2, drible: 2, habilidade: 1, agressividade: 2, desarme: -1, reflexos: 1, agilidade: 1 },
    forte: "criatividade e drible", burocracia: "Fora da UE: certificado internacional de transferência e visto levam semanas.",
  },
  cl: {
    nome: "Chile", nac: "Chile", pais: "pt", divisoes: [], custoMult: 2.0, dias: [28, 35], nivelMin: 1,
    registoDias: [20, 32], adaptDias: 90, adaptPen: 0.06, ovrOff: -1,
    escola: "Escola chilena: garra, disciplina e muita margem de crescimento.",
    bias: { determinacao: 2, resistencia: 1, finalizacao: 1, posicionamento: -1, concentracao: 1 },
    forte: "garra e determinação", burocracia: "Fora da UE: certificado internacional de transferência e visto levam semanas.",
  },
  ao: {
    nome: "Angola", nac: "Angola", pais: "pt", divisoes: [], custoMult: 2.2, dias: [30, 40], nivelMin: 1,
    registoDias: [25, 40], adaptDias: 100, adaptPen: 0.07, ovrOff: -1,
    escola: "Escola angolana: velocidade e fisicalidade, com ligação histórica ao hóquei português.",
    bias: { velocidade: 2, aceleracao: 2, forca: 1, posicionamento: -1, criatividade: -1, agilidade: 1 },
    forte: "velocidade e força", burocracia: "Fora da UE: certificado internacional de transferência e visto levam semanas.",
  },
};
const SCINT_ORDEM = ["es", "it", "fr", "ar", "cl", "ao"];
const SCINT_FOCOS = {
  prontos:   { label: "Jogadores prontos", desc: "Jogadores feitos, para reforçar o plantel já.", custoMult: 1.0 },
  promessas: { label: "Promessas", desc: "17-21 anos, nível baixo hoje e muita margem.", custoMult: 1.1 },
  gr:        { label: "Guarda-redes", desc: "Procura só guarda-redes.", custoMult: 1.0 },
};
const SCINT_EXCLUSIVO_DIAS = 14;
const SCINT_CONHECIMENTO_GANHO = 18;
const SCINT_NOME_CODIGO = { es: "es", it: "it", fr: "fr", ar: "es", cl: "es", ao: "pt" };

function scintEnsure(team){
  if(!team.scoutingInternacional || typeof team.scoutingInternacional !== "object") team.scoutingInternacional = {};
  const si = team.scoutingInternacional;
  if(!Array.isArray(si.missoes)) si.missoes = [];
  if(!Array.isArray(si.historico)) si.historico = [];
  if(!si.conhecimento || typeof si.conhecimento !== "object") si.conhecimento = {};
  if(!si.observados || typeof si.observados !== "object") si.observados = {};
  if(!Number.isFinite(si.seq)) si.seq = 0;
  return si;
}
function scintElegivel(team){ return !!team && isUserControlledTeam(team); }

// Conhecimento do país (0-100): sobe com cada missão e vai-se perdendo devagar (-5 por 60 dias).
function scintConhecimento(team, pais){
  const k = scintEnsure(team).conhecimento[pais];
  if(!k) return 0;
  const dias = Math.max(0, (new Date(state.currentDate) - new Date(k.data)) / 86400000);
  return clamp(Math.round(k.valor - Math.floor(dias / 60) * 5), 0, 100);
}
function scintConhecimentoLabel(c){
  return c <= 0 ? "Nenhum" : c < 25 ? "Reduzido" : c < 55 ? "Médio" : c < 80 ? "Bom" : "Excelente";
}
function scintNivel(team){ return ensureTeamScouting(team).departamento.nivel; }
function scintCusto(team, pais, foco){
  const P = SCINT_PAISES[pais], F = SCINT_FOCOS[foco] || SCINT_FOCOS.prontos;
  const base = Math.max(450, avgMonthlySalary(team));
  const desconto = 1 - 0.1 * Math.max(0, scintNivel(team) - 1);
  return Math.max(600, Math.round(base * P.custoMult * F.custoMult * desconto / 10) * 10);
}
function scintDias(team, pais, seq){
  const P = SCINT_PAISES[pais];
  const rng = makeSeededRng(`scint-dias|${team.id}|${pais}|${seq}`);
  return seededRnd(rng, P.dias[0], P.dias[1]);
}
function scintVagasLivres(team){
  const cfg = scoutingLevelConfig(team), sc = ensureTeamScouting(team), si = scintEnsure(team);
  return cfg.capacidade - sc.pedidos.length - si.missoes.length;
}
function scintPodeEnviar(team, pais, foco){
  const P = SCINT_PAISES[pais];
  if(!P || !SCINT_FOCOS[foco]) return { ok: false, reason: "Missão inválida." };
  const si = scintEnsure(team);
  if(scintNivel(team) < P.nivelMin) return { ok: false, reason: `O departamento de scouting ainda não tem estrutura para missões em ${P.nome} (precisa de nível ${P.nivelMin}).` };
  if(si.missoes.some(m => m.pais === pais)) return { ok: false, reason: `Já há um olheiro em missão em ${P.nome}.` };
  if(scintVagasLivres(team) <= 0) return { ok: false, reason: "O departamento de scouting está no limite de pedidos em curso." };
  return { ok: true };
}
function scintEnviar(team, pais, foco){
  const chk = scintPodeEnviar(team, pais, foco);
  if(!chk.ok) return chk;
  const P = SCINT_PAISES[pais], si = scintEnsure(team);
  const custo = scintCusto(team, pais, foco);
  const seq = ++si.seq;
  const dias = scintDias(team, pais, seq);
  addFinanceMovement(team, "despesa", "Scouting", `Missão de scouting em ${P.nome} (${SCINT_FOCOS[foco].label.toLowerCase()})`, custo, state.currentDate);
  si.missoes.push({ id: `scint-${seq}`, pais, foco, custo, dias, seq,
    inicio: new Date(state.currentDate).toISOString(), pronta: addDays(state.currentDate, dias).toISOString() });
  return { ok: true, custo, dias };
}

// ---------- geração dos talentos livres ----------
function scintGerarJogador(team, pais, foco, rng, conh, indice, seq){
  const P = SCINT_PAISES[pais];
  const gr = foco === "gr";
  const promessa = foco === "promessas";
  const ref = gr
    ? (() => { const g = team.players.filter(p => p.pos === "GR"); return g.length ? g.reduce((s, p) => s + overall(p), 0) / g.length : clubAverageOutfieldOverall(team); })()
    : clubAverageOutfieldOverall(team);
  const joia = rng() < 0.10 + conh / 500;
  let alvo = promessa ? ref - 3 + P.ovrOff * 0.6 : ref - 0.5 + P.ovrOff * 0.6 + conh * 0.01;
  alvo += seededRndFloat(rng, -1.2, 1.2) + (joia ? 2 : 0);
  alvo = clamp(Math.round(alvo), 7, 19);
  const age = promessa ? seededRnd(rng, 17, 21) : gr ? seededRnd(rng, 22, 33) : seededRnd(rng, 22, 31);
  const id = `scint-${state.season}-${seq}-${indice}`;
  const nome = randomNameForCountry(SCINT_NOME_CODIGO[pais] || "pt", rng);
  const p = gr
    ? makeGoalkeeper(id, rnd(1, 99), nome, alvo, team.divisaoAtual, P.pais)
    : makeOutfieldPlayer(id, rnd(1, 99), nome, alvo, team.divisaoAtual, P.pais);
  // viés da escola + reajuste ao nível alvo
  Object.keys(P.bias).forEach(k => { if(p.attrs[k] != null) p.attrs[k] = clampAttr(p.attrs[k] + P.bias[k]); });
  const fixos = { agressividade: 1, determinacao: 1, lideranca: 1 };
  const dif = alvo - overall(p);
  if(dif) Object.keys(p.attrs).forEach(k => { if(!fixos[k]) p.attrs[k] = clampAttr(p.attrs[k] + dif); });
  p.age = age;
  p.dataNascimento = makeBirthDate(rng, age, new Date(state.currentDate));
  const ovr = overall(p);
  p.potential = promessa ? clampAttr(ovr + seededRnd(rng, 4, 8)) : age <= 25 ? clampAttr(ovr + seededRnd(rng, 0, 3)) : clampAttr(ovr + seededRnd(rng, 0, 1));
  if(joia && !promessa) p.potential = clampAttr(Math.max(p.potential, ovr + 2));
  p.nacionalidade = P.nac;
  p.paisOrigem = normalizeCountryCode(P.pais);
  p.contrato = null; p.preContrato = null;
  const dr = P.registoDias;
  p.scint = {
    pais, escola: P.nome, missaoSeq: seq, descobertoEm: new Date(state.currentDate).toISOString(), descobertoEpoca: state.season,
    exclusivoAte: addDays(state.currentDate, SCINT_EXCLUSIVO_DIAS).getTime(),
    registoDias: seededRnd(rng, dr[0], dr[1]), adaptDias: P.adaptDias, adaptPen: P.adaptPen,
    protegidoAteEpoca: state.season + 1,
  };
  return p;
}
function scintPotLabel(p, conh, rng){
  const erro = conh >= 60 ? 1 : conh >= 25 ? 2 : 3;
  const est = clampAttr(p.potential + seededRnd(rng, -erro, erro));
  const m = est - overall(p);
  return m <= 1 ? "Limitada" : m <= 3 ? "Regular" : m <= 5 ? "Interessante" : m <= 7 ? "Elevada" : "Excecional";
}
function scintFortes(p){
  const keys = SCOUTING_ATTR_LABELS[p.pos] || SCOUTING_ATTR_LABELS.J;
  const ord = keys.map(([k, lab]) => ({ lab, v: p.attrs[k] })).sort((a, b) => b.v - a.v);
  return { fortes: ord.slice(0, 2).map(a => a.lab), fraco: ord[ord.length - 1].lab };
}
// Pistas: relatórios rápidos sobre jogadores reais dos clubes do país (só Espanha e Itália, onde
// há clubes no jogo).
function scintPistas(team, pais, rng, n){
  const P = SCINT_PAISES[pais];
  if(!P.divisoes.length) return [];
  const sc = ensureTeamScouting(team);
  const ref = clubAverageOutfieldOverall(team);
  const candidatos = [];
  Object.values(state.teams).forEach(t => {
    if(t.id === team.id || !P.divisoes.includes(t.divisaoAtual) || t.equipaPrincipalId) return;
    (t.players || []).forEach(p => {
      if(p.age > 28 || sc.relatorios[p.id] || p.emprestimo) return;
      const ovr = overall(p);
      if(ovr < ref - 1.5) return;
      candidatos.push({ p, t, score: ovr + (p.potential - ovr) * 0.5 - Math.max(0, p.age - 24) * 0.3 + rng() * 2 });
    });
  });
  candidatos.sort((a, b) => b.score - a.score);
  const out = [];
  candidatos.slice(0, Math.max(6, n * 3)).sort(() => rng() - 0.5).slice(0, n).forEach(c => {
    const tier = scoutingDistanceTier(c.t);
    sc.relatorios[c.p.id] = {
      resolvedDate: new Date(state.currentDate).toISOString(), tier, tipo: "rapido",
      targetTeamId: c.t.id, targetTeamName: c.t.name, playerName: c.p.name,
      dossie: buildScoutingDossier(c.p, c.t, tier, "rapido"), ficha: null,
    };
    sc.relatorios[c.p.id].ficha = { idade: c.p.age, pos: scoutingPositionLabel(c.p), ovr: Math.round(visibleOverall(c.p, c.t)), pot: visiblePotentialLabel(c.p, c.t), divisao: scoutingDivisionLabel(c.t.divisaoAtual) };
    out.push(c);
  });
  return out;
}

function scintResolverMissao(team, m){
  const P = SCINT_PAISES[m.pais], si = scintEnsure(team);
  const rng = makeSeededRng(`scint-res|${team.id}|${m.pais}|${m.seq}|${state.season}`);
  const conh = scintConhecimento(team, m.pais), nivel = scintNivel(team);
  let n = m.foco === "gr" ? 1 + (conh >= 50 ? 1 : 0) : 2 + (nivel >= 2 ? 1 : 0) + (conh >= 50 ? 1 : 0);
  n = clamp(n, 1, 4);
  const talentos = [];
  for(let i = 0; i < n; i++){
    const p = scintGerarJogador(team, m.pais, m.foco, rng, conh, i, m.seq);
    state.freeAgents = (state.freeAgents || []).concat(p);
    si.observados[p.id] = true;
    talentos.push(p);
  }
  const pistas = scintPistas(team, m.pais, rng, m.foco === "gr" ? 0 : (1 + (conh >= 50 ? 1 : 0)));
  si.conhecimento[m.pais] = { valor: clamp(conh + SCINT_CONHECIMENTO_GANHO + nivel * 4, 0, 100), data: new Date(state.currentDate).toISOString() };
  const reg = {
    pais: m.pais, foco: m.foco, custo: m.custo, inicio: m.inicio, fim: new Date(state.currentDate).toISOString(),
    talentos: talentos.map(p => p.id), pistas: pistas.map(c => c.p.id),
  };
  si.historico.unshift(reg);
  if(si.historico.length > 12) si.historico.length = 12;
  scintEmailMissao(team, m, talentos, pistas, conh, rng);
}
function scintLinkLivre(p){
  return `<button class="playername-btn scint-fa-btn" data-id="${p.id}">${playerNameHtml(p)}</button>`;
}
function scintEmailMissao(team, m, talentos, pistas, conh, rng){
  const P = SCINT_PAISES[m.pais], foco = SCINT_FOCOS[m.foco];
  const linhasT = talentos.map(p => {
    const f = scintFortes(p);
    const ovrEst = Math.round(overall(p) + seededRnd(rng, conh >= 60 ? -1 : -2, conh >= 60 ? 1 : 2));
    return [scintLinkLivre(p), `${scoutingPositionLabel(p)} · ${p.age} anos · OVR ≈ ${ovrEst} · potencial ${scintPotLabel(p, conh, rng).toLowerCase()}<br><span class="helptext">Destaca-se em ${escapeHtml(f.fortes.join(" e "))}; mais fraco em ${escapeHtml(f.fraco)}. Inscrição: cerca de ${p.scint.registoDias} dias.</span>`];
  });
  const linhasP = pistas.map(c => [playerLinkHtml(c.t.id, c.p), `${escapeHtml(c.t.name)} · ${scoutingPositionLabel(c.p)} · ${c.p.age} anos<br><span class="helptext">Relatório rápido já disponível no separador Scouting.</span>`]);
  const exclusivo = fmtDateShort(new Date(addDays(state.currentDate, SCINT_EXCLUSIVO_DIAS)));
  const chips = [repChip(P.nome), repChip(`${talentos.length} talento${talentos.length === 1 ? "" : "s"} sem clube`, talentos.length ? "ok" : "aviso")];
  if(P.divisoes.length) chips.push(repChip(`${pistas.length} pista${pistas.length === 1 ? "" : "s"} em clubes`));
  chips.push(repChip(foco.label));
  const html = repDoc({
    teamId: team.id, org: "Departamento de scouting", titulo: `Missão a ${escapeHtml(P.nome)} concluída`,
    sub: `${fmtDateLong(new Date(state.currentDate))}`,
    chips,
    resumo: talentos.length
      ? `O nosso olheiro regressou de ${escapeHtml(P.nome)} com ${talentos.length} jogador${talentos.length === 1 ? "" : "es"} sem clube que valem uma conversa. Temos exclusividade até ${exclusivo}; depois outros clubes podem avançar.`
      : `O olheiro regressou de ${escapeHtml(P.nome)} sem nomes concretos para apresentar.`,
    secoes: [
      { icone: "🏫", titulo: "A escola", texto: escapeHtml(P.escola) },
      linhasT.length ? { icone: "🧭", titulo: "Talentos sem clube", linhas: linhasT, cheia: true } : null,
      linhasP.length ? { icone: "🔎", titulo: "Pistas em clubes", linhas: linhasP, cheia: true } : null,
      { icone: "🛂", titulo: "Burocracia e adaptação", texto: `${escapeHtml(P.burocracia)} Depois de inscrito, um jogador desta escola leva cerca de ${P.adaptDias} dias a render por inteiro${m.pais === "es" || m.pais === "it" || m.pais === "fr" ? "" : " — e mais ainda sem um compatriota no balneário"}. Valores estimados.` },
    ],
    rodape: "Estimativas do olheiro: o nível real só se confirma depois da contratação",
  });
  pushNews(state.currentDate, html, "scouting", `Missão a ${P.nome}: relatório do olheiro`, { autoAdvanceStop: true });
}

// Corrido uma vez por dia (09-fluxo-epoca.js).
function scintDiario(date){
  const team = myTeam();
  if(!team || !scintElegivel(team)) return;
  const si = scintEnsure(team);
  const hoje = new Date(date);
  const prontas = si.missoes.filter(m => new Date(m.pronta) <= hoje);
  if(prontas.length){
    si.missoes = si.missoes.filter(m => new Date(m.pronta) > hoje);
    prontas.forEach(m => scintResolverMissao(team, m));
  }
  // avisa quando um jogador vindo de fora fica finalmente inscrito
  team.players.forEach(p => {
    if(p.scint && p.scint.registoAte && !p.scint.registoAvisado && hoje.getTime() > p.scint.registoAte){
      p.scint.registoAvisado = true;
      pushNews(date, `${playerLinkHtml(team.id, p)} já tem a inscrição regularizada e está disponível para jogar. A adaptação ao novo país e ao clube deve prolongar-se por mais algumas semanas.`, "scouting", `${p.name}: inscrição concluída`, { autoAdvanceStop: false });
    }
  });
}

// ---------- contratação, inscrição e adaptação ----------
function scintReservado(p){
  return !!(p && p.scint && !p.scint.assinado && p.scint.exclusivoAte && new Date(state.currentDate).getTime() <= p.scint.exclusivoAte);
}
function scintAoContratar(team, p){
  if(!p || !p.scint || p.scint.assinado) return;
  const s = p.scint;
  s.assinado = true;
  const agora = new Date(state.currentDate).getTime();
  s.registoAte = agora + s.registoDias * 86400000;
  const compat = team.players.some(x => x.id !== p.id && x.nacionalidade === p.nacionalidade);
  s.adaptPenEf = s.adaptPen * (compat ? 0.5 : 1);
  s.compatriota = compat;
  s.adaptIni = s.registoAte;
  s.adaptAte = s.registoAte + s.adaptDias * 86400000;
  p.num = findFreeNumber(team);
  if(scintElegivel(team)){
    pushNews(state.currentDate, `${playerLinkHtml(team.id, p)} (${escapeHtml(s.escola)}) assinou, mas só poderá jogar depois de concluída a inscrição, prevista para ${fmtDateShort(new Date(s.registoAte))}.${compat ? " Já tem um compatriota no balneário, o que deve ajudar na adaptação." : ""}`, "scouting", `${p.name}: a aguardar inscrição`, { autoAdvanceStop: false });
  }
}
function scintIndisponivelMotivo(p){
  if(p && p.scint && p.scint.registoAte && new Date(state.currentDate).getTime() <= p.scint.registoAte) return "A aguardar inscrição";
  return null;
}
function scintAdaptacaoFactor(p){
  const s = p && p.scint;
  if(!s || !s.adaptAte) return 1;
  const t = new Date(state.currentDate).getTime();
  if(t >= s.adaptAte) return 1;
  const dur = Math.max(1, s.adaptAte - s.adaptIni);
  const restante = clamp((s.adaptAte - Math.max(t, s.adaptIni)) / dur, 0, 1);
  return 1 - (s.adaptPenEf || s.adaptPen || 0) * restante;
}
function scintAdaptacaoTexto(p){
  const s = p && p.scint;
  if(!s || !s.adaptAte) return null;
  const t = new Date(state.currentDate).getTime();
  if(s.registoAte && t <= s.registoAte) return `A aguardar inscrição até ${fmtDateShort(new Date(s.registoAte))}`;
  if(t < s.adaptAte) return `Em adaptação até ${fmtDateShort(new Date(s.adaptAte))} (${Math.round((1 - scintAdaptacaoFactor(p)) * 100)}% abaixo do rendimento normal)`;
  return null;
}

// ---------- interface ----------
function scintHtml(team){
  const si = scintEnsure(team);
  const sc = ensureTeamScouting(team), cfg = scoutingLevelConfig(team);
  const usadas = sc.pedidos.length + si.missoes.length;
  const linhas = SCINT_ORDEM.map(pais => {
    const P = SCINT_PAISES[pais];
    const missao = si.missoes.find(m => m.pais === pais);
    const conh = scintConhecimento(team, pais);
    const bloqueado = scintNivel(team) < P.nivelMin;
    let acao;
    if(missao){
      acao = `<b>Olheiro em missão</b><br><span class="helptext">Regressa a ${fmtDateShort(new Date(missao.pronta))}</span>`;
    }else if(bloqueado){
      acao = `<span class="helptext">Precisa de scouting nível ${P.nivelMin}</span>`;
    }else{
      const opts = Object.keys(SCINT_FOCOS).map(f => `<option value="${f}">${SCINT_FOCOS[f].label} · ${fmtMoney(scintCusto(team, pais, f))}</option>`).join("");
      acao = `<div style="display:flex;gap:6px;flex-wrap:wrap;align-items:center;"><select data-scint-foco="${pais}">${opts}</select>
        <button class="btn btn-primary" data-scint-enviar="${pais}"${usadas >= cfg.capacidade ? " disabled" : ""}>Enviar olheiro</button></div>`;
    }
    return `<div class="fixture-row" style="display:flex;justify-content:space-between;gap:14px;align-items:flex-start;flex-wrap:wrap;">
      <span style="flex:1 1 320px;"><img class="nat-flag" src="img/flags/${pais}.svg" alt=""> <b>${P.nome}</b> · ${P.dias[0]}-${P.dias[1]} dias · conhecimento: ${scintConhecimentoLabel(conh)}<br>
        <span class="helptext">${escapeHtml(P.escola)} Forte em ${P.forte}. ${escapeHtml(P.burocracia)}${P.divisoes.length ? " Também deixa pistas sobre jogadores dos clubes do país." : ""}</span></span>
      <span>${acao}</span></div>`;
  }).join("");
  const ids = new Set();
  si.historico.forEach(h => (h.talentos || []).forEach(id => ids.add(id)));
  const descobertas = [];
  ids.forEach(id => {
    const livre = (state.freeAgents || []).find(p => p.id === id);
    const meu = team.players.find(p => p.id === id);
    const outro = !livre && !meu ? Object.values(state.teams).find(t => t.players.some(p => p.id === id)) : null;
    const pl = livre || meu || (outro && outro.players.find(p => p.id === id));
    if(!pl) return;
    let estado;
    if(livre) estado = scintReservado(livre) ? `Livre · exclusividade até ${fmtDateShort(new Date(livre.scint.exclusivoAte))}` : "Livre";
    else if(meu) estado = scintAdaptacaoTexto(meu) || "No nosso plantel";
    else estado = `Contratado por ${outro.name}`;
    descobertas.push(`<div class="fixture-row" style="display:flex;justify-content:space-between;gap:12px;"><span>${livre ? scintLinkLivre(pl) : playerLinkHtml(meu ? team.id : outro.id, pl)} · ${scoutingPositionLabel(pl)} · ${pl.age} anos · ${escapeHtml(pl.scint ? pl.scint.escola : "")}</span><span class="helptext">${estado}</span></div>`);
  });
  return `<div class="eyebrow" style="margin:6px 0 8px;">Scouting internacional</div>
    <p class="helptext" style="margin:0 0 8px;">Envia um olheiro a uma escola estrangeira: leva semanas, custa dinheiro e ocupa uma vaga do departamento (${usadas}/${cfg.capacidade} em uso). Traz talentos sem clube e, em Espanha e Itália, pistas sobre jogadores de clubes. Quem vem de fora tem de esperar pela inscrição e demora a adaptar-se, sobretudo fora da UE. Custos, prazos e níveis são estimativas do jogo.</p>
    ${linhas}
    ${descobertas.length ? `<div class="eyebrow" style="margin:14px 0 6px;">Descobertas (${descobertas.length})</div>${descobertas.join("")}` : ""}
    <div style="margin-bottom:14px;"></div>`;
}
function scintRender(team){
  const box = document.getElementById("scoutingInternacionalSection");
  if(!box) return;
  if(!team || !scintElegivel(team)){ box.innerHTML = ""; return; }
  box.innerHTML = scintHtml(team);
  box.querySelectorAll("[data-scint-enviar]").forEach(btn => btn.addEventListener("click", () => {
    const pais = btn.getAttribute("data-scint-enviar");
    const sel = box.querySelector(`[data-scint-foco="${pais}"]`);
    const r = scintEnviar(team, pais, sel ? sel.value : "prontos");
    if(!r.ok){ alert(r.reason); return; }
    renderTransferMarket();
  }));
}
document.addEventListener("click", e => {
  const b = e.target && e.target.closest ? e.target.closest(".scint-fa-btn") : null;
  if(!b) return;
  e.preventDefault(); e.stopPropagation();
  goToFreeAgentInMarket(b.getAttribute("data-id"));
});
