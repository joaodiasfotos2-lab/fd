// =====================================================================
// 0.3.5 — Estilo de transição (Contra-ataque direto / Equilibrado / Construção apoiada)
//
// Origem: relatório "Táticas e sistemas no hóquei em patins" (outubro 2026) — o contra-ataque
// direto aproveita a desorganização do adversário com poucos passes e muita velocidade, mas gasta
// mais e perde qualidade de remate; a construção apoiada circula a bola, procura o melhor remate
// e poupa fôlego, mas dá tempo ao adversário para se organizar (e sofre contra marcação individual).
//
// Valores = ESTIMATIVAS de jogo, pequenas de propósito. "Equilibrado" (omissão) é neutro, para não
// mexer na calibração do campeonato. Dado guardado em team.transicao ("direta"|"equilibrada"|"apoiada").
// A equipa que ATACA é `att`, a que defende é `def`.
// =====================================================================
const TRANSICAO_TIPOS = Object.freeze({
  direta:     { label:"Contra-ataque direto", curto:"Poucos passes e muita velocidade: mais remates, mas de pior qualidade, e mais desgaste.",
                bom:"Plantel veloz, adversário que sobe no campo e deixa espaço, equipas que defendem à zona e demoram a recompor.", mau:"Com avançados lentos ou contra defesa individual forte, que anula a corrida." },
  equilibrada:{ label:"Equilibrado", curto:"Alterna ataque rápido e posse, conforme o jogo pede. Sem efeitos extra.",
                bom:"Plantel sem um perfil claro (rápido ou técnico).", mau:"Não explora nenhum ponto forte em especial." },
  apoiada:    { label:"Construção apoiada", curto:"Circula a bola e procura o melhor remate: menos remates, mais qualidade, e poupa fôlego.",
                bom:"Plantel técnico e criativo, contra defesa à zona, para controlar o ritmo.", mau:"Contra defesa individual agressiva (dificulta as receções) e com pouca criatividade." }
});
function transicaoTipo(team){ return team && TRANSICAO_TIPOS[team.transicao] ? team.transicao : "equilibrada"; }
function transicaoAvgAttr(players, keys){
  if(!players.length) return 12;
  const v = players.map(p=>keys.reduce((a,k)=>a+(p.attrs && p.attrs[k]!=null ? p.attrs[k] : 12),0)/keys.length);
  return v.reduce((a,b)=>a+b,0)/v.length;
}
function transicaoPace(team){ return transicaoAvgAttr(team.players.filter(p=>p.pos==="J"), ["velocidade","aceleracao"]); }
function transicaoTech(team){ return transicaoAvgAttr(team.players.filter(p=>p.pos==="J"), ["habilidade","criatividade"]); }

function transicaoConversionMult(att, def){
  const t = transicaoTipo(att);
  if(t==="direta"){
    const edge = clamp((transicaoPace(att) - 13)/5, -1, 1);
    const vsDef = def ? (defesaTipo(def)==="zona" ? 1.01 : defesaTipo(def)==="individual" ? 0.985 : 1) : 1;
    return 0.975 * (1 + 0.05*edge) * vsDef;
  }
  if(t==="apoiada"){
    const edge = clamp((transicaoTech(att) - 13)/5, -1, 1);
    const vsDef = def ? (defesaTipo(def)==="zona" ? 1.015 : defesaTipo(def)==="individual" ? 0.985 : 1) : 1;
    return 1.015 * (1 + 0.045*edge) * vsDef;
  }
  return 1;
}
function transicaoShotMult(att){ const t = transicaoTipo(att); return t==="direta" ? 1.05 : t==="apoiada" ? 0.95 : 1; }
function transicaoFatigueMult(team){ const t = transicaoTipo(team); return t==="direta" ? 1.08 : t==="apoiada" ? 0.97 : 1; }

function transicaoSugestao(team){
  const J = team.players.filter(p=>p.pos==="J");
  if(J.length < 4) return { tipo:"equilibrada", motivo:"plantel curto" };
  const d = transicaoPace(team) - transicaoTech(team);
  if(d > 1.2) return { tipo:"direta", motivo:"plantel mais veloz do que técnico" };
  if(d < -1.2) return { tipo:"apoiada", motivo:"plantel mais técnico do que veloz" };
  return { tipo:"equilibrada", motivo:"velocidade e técnica equilibradas" };
}
function chooseAiTransicao(team){
  if(typeof window!=="undefined" && window.__HM2027_EXPOSE_TEST_HOOKS__ && window.__HM2027_FORCE_TRANSICAO) return window.__HM2027_FORCE_TRANSICAO;
  return transicaoSugestao(team).tipo;
}
function transicaoHelpHtml(team){
  const t = transicaoTipo(team), d = TRANSICAO_TIPOS[t], s = transicaoSugestao(team), sd = TRANSICAO_TIPOS[s.tipo];
  return `<b>${d.label}:</b> ${d.curto}<br><b>Funciona melhor:</b> ${d.bom} <b>Cuidado:</b> ${d.mau}<br>Sugestão para o teu plantel: <b>${sd.label}</b> (${s.motivo}).`;
}
function transicaoSyncHelp(){
  const el = document.getElementById("transicaoHelp"); const team = myTeam();
  if(el && team) el.innerHTML = transicaoHelpHtml(team);
}
