// ============================= 08zf-negociacao-modal.js =============================
// Negociação de jogador — janela própria (0.3.2)
// Pedido do utilizador: "não gosto do menu de fazer a proposta pelo jogador nem de propor o
// contrato". Os formulários dentro da ficha do jogador (apertados, com o botão cortado e as
// cláusulas de empréstimo a ocupar metade do ecrã) dão lugar a uma janela com passos:
//   1. Clube   — proposta de compra ao clube, ou pedido de empréstimo (separadores)
//   2. Jogador — salário, duração e papel, com o custo para o clube sempre à vista
//   3. Confirmar — proposta enviada e data prevista da resposta
// Usa os mesmos motores de sempre (negotiateWithClub, proposeLoan, proposeContract): a janela só
// substitui a interface, não as regras.
// ====================================================================================
let nmCtx = null;

function nmLoanNote(player, fromTeam, toTeam){
  const session = (state.loanNegotiations || {})[loanNegotiationKey(player, fromTeam, toTeam)];
  return session || null;
}

function openNegotiationModal(opts){
  const toTeam = state.teams[opts.toId];
  const fromTeam = opts.fromId ? state.teams[opts.fromId] : null;
  if(!toTeam) return;
  const kind = opts.kind;
  const player = fromTeam
    ? fromTeam.players.find(p => p.id === opts.playerId)
    : ((state.freeAgents || []).find(p => p.id === opts.playerId) || toTeam.players.find(p => p.id === opts.playerId));
  if(!player) return;
  const external = kind === "transferencia" && !!fromTeam && fromTeam.id !== toTeam.id;
  const loanOnly = !!opts.loanOnly;
  const fee = external ? agreedTransferFee(player, fromTeam, toTeam) : null;
  const hasClubStep = external && !loanOnly && fee == null && marketPeriodForDate(state.currentDate) !== "pre-contratos";
  const clubStepAvailable = external && (hasClubStep || loanOnly);
  const negKey = negotiationSessionKey(kind, player, fromTeam, toTeam);
  const session = (state.contractNegotiations || {})[negKey];
  const counter = session && session.counter ? session.counter : null;
  const demand = (kind === "renovacao") ? null : contractDemand(player, fromTeam, toTeam, null, kind);
  const salarioSug = counter ? counter.salarioMensal
    : kind === "renovacao" ? (player.contrato ? player.contrato.salarioMensal : expectedSalary(player, toTeam))
    : Math.round(demand.salarioMensal);
  const estimate = external ? clubTransferDemand(player, fromTeam, toTeam) : 0;
  // 0.4.9: piso salarial do clube pagador (0 € na 2.ª/3.ª divisão, onde se joga por gosto); 450 € no Placard.
  const salFloor = Math.min(450, divisionSalaryProfile(toTeam.divisaoAtual).base);
  nmCtx = {
    kind, player, fromTeam, toTeam, external, loanOnly, onChanged: opts.onChanged || function(){},
    step: opts.step || (clubStepAvailable ? "clube" : "jogador"),
    steps: loanOnly ? ["clube", "confirmar"] : ((clubStepAvailable || (external && fee != null)) ? ["clube", "jogador", "confirmar"] : ["jogador", "confirmar"]),
    tab: loanOnly ? "emprestimo" : "comprar",
    estimate, marketValue: external ? playerMarketValue(player, fromTeam) : 0,
    valor: Math.max(0, estimate), fee,
    salFloor,
    salario: Math.max(salFloor, Math.round(salarioSug / 50) * 50), salarioSug: Math.max(salFloor, Math.round(salarioSug)),
    anos: counter ? counter.anos : (kind === "renovacao" ? (player.contrato ? player.contrato.anos : 2) : 2),
    papel: counter ? counter.papel : (player.contrato && player.contrato.papel ? player.contrato.papel : "Rotacao"),
    counter,
    share: 50, loanRole: "Rotacao",
    erro: "", enviado: null,
  };
  if(!PLAYER_ROLES.includes(nmCtx.papel)) nmCtx.papel = "Rotacao";
  if(![1, 2, 3].includes(nmCtx.anos)) nmCtx.anos = 2;
  nmMount();
  nmRender();
}

function nmMount(){
  let root = document.getElementById("nmOverlay");
  if(root) root.remove();
  root = document.createElement("div");
  root.id = "nmOverlay";
  root.className = "nm-overlay";
  root.innerHTML = `<div class="nm-modal" role="dialog" aria-modal="true"><div id="nmBox"></div></div>`;
  document.body.appendChild(root);
  root.addEventListener("click", nmOnClick);
  root.addEventListener("input", nmOnInput);
  root.addEventListener("change", nmOnInput);
  document.addEventListener("keydown", nmOnKey);
}
function nmOnKey(e){ if(e.key === "Escape" && document.getElementById("nmOverlay")) nmClose(); }
function nmClose(){
  const root = document.getElementById("nmOverlay");
  if(root) root.remove();
  document.removeEventListener("keydown", nmOnKey);
  const cb = nmCtx && nmCtx.onChanged;
  nmCtx = null;
  if(cb) cb();
}

function nmRound(v, step){ return Math.round(v / step) * step; }

// ----- cabeçalho -----
function nmHeaderHtml(){
  const c = nmCtx, p = c.player;
  const crestTeam = c.fromTeam || c.toTeam;
  const crest = clubCrestUrl(crestTeam && crestTeam.id);
  const crestHtml = crest ? `<img src="${crest}" alt="" class="nm-crest-img">` : `<span>${escapeHtml(((crestTeam && crestTeam.name) || "?").slice(0, 3).toUpperCase())}</span>`;
  const linha = typeof linhaAbbrev === "function" ? linhaAbbrev(p) : "";
  const clubTxt = c.kind === "renovacao" ? escapeHtml(c.toTeam.name) : (c.fromTeam ? escapeHtml(c.fromTeam.name) : "Agente livre");
  let ovr, pot = "";
  if(c.fromTeam && c.fromTeam.id !== c.toTeam.id){
    ovr = Math.round(visibleOverall(p, c.fromTeam));
    pot = visiblePotentialLabel(p, c.fromTeam);
  } else if(!c.fromTeam){
    ovr = (typeof experienciaOvrTexto === "function") ? experienciaOvrTexto(p) : overall(p);
  } else ovr = overall(p);
  const sub = c.step === "jogador" && c.fee != null && c.external
    ? `Acordo com o ${escapeHtml(c.fromTeam.name)}: <b class="nm-ok">${fmtMoney(c.fee)}</b> · falta o contrato do jogador`
    : `${linha ? linha + " · " : ""}${p.age} anos · ${clubTxt}${p.contrato ? " · " + contractStatusLabel(p).toLowerCase() : ""}`;
  return `<div class="nm-head">
    <div class="nm-crest">${crestHtml}</div>
    <div class="nm-head-t"><h1>${playerNameHtml ? escapeHtml(p.name) : escapeHtml(p.name)}</h1><p>${sub}</p></div>
    <div class="nm-pills"><div class="nm-pill"><b>${ovr}</b><span>OVR</span></div>${pot && pot !== "Incerta" ? `<div class="nm-pill"><b>${escapeHtml(pot)}</b><span>Potencial</span></div>` : ""}</div>
    <button class="nm-x" data-nm="close" aria-label="Fechar">✕</button>
  </div>`;
}
function nmStepperHtml(){
  const c = nmCtx;
  const labels = { clube: "Clube", jogador: "Jogador", confirmar: "Confirmar" };
  const idx = c.steps.indexOf(c.step);
  const parts = c.steps.map((s, i) => {
    const cls = i < idx ? "done" : (i === idx ? "on" : "");
    return `<div class="nm-st ${cls}"><span class="n">${i < idx ? "✓" : i + 1}</span>${labels[s]}</div>`;
  });
  const tabs = (c.step === "clube" && !c.loanOnly)
    ? `<div class="nm-tabs"><button class="nm-tab ${c.tab === "comprar" ? "on" : ""}" data-nm="tab" data-v="comprar">Comprar</button><button class="nm-tab ${c.tab === "emprestimo" ? "on" : ""}" data-nm="tab" data-v="emprestimo">Pedir emprestado</button></div>` : "";
  return `<div class="nm-stepper">${parts.join('<div class="nm-bar"></div>')}${tabs}</div>`;
}

// ----- passo 1: clube -----
function nmRailHtml(valorPct, markers, fillId, extra){
  return `<div class="nm-rail"><div class="nm-fill" id="${fillId}" style="width:${valorPct}%"></div>${markers}${extra || ""}</div>`;
}
function nmClubMax(){
  const c = nmCtx;
  const budget = Math.max(0, (c.toTeam.financeiro && c.toTeam.financeiro.orcamentoTransferencias) || 0);
  return Math.max(500, nmRound(Math.max(c.estimate * 1.8, c.marketValue * 2, budget * 1.05, 2000), 500));
}
function nmClubImpactHtml(){
  const c = nmCtx;
  const budget = (c.toTeam.financeiro && c.toTeam.financeiro.orcamentoTransferencias) || 0;
  const depois = budget - c.valor;
  const over = depois < 0;
  const pctUsed = budget > 0 ? Math.min(100, Math.round(c.valor / budget * 100)) : 100;
  return `<h2>Impacto no clube</h2>
    <div class="nm-kv"><span>Orçamento de transferências</span><b>${fmtMoney(budget)}</b></div>
    <div class="nm-kv"><span>Depois da transferência</span><b class="${over ? "r" : "g"}">${fmtMoney(depois)}</b></div>
    <div class="nm-budget"><i style="width:${over ? 100 : pctUsed}%;background:${over ? "#ff8a7a" : "linear-gradient(90deg,#6b7bff,#a05bff)"}"></i></div>
    ${over ? `<div class="nm-note warn">⚠️ A proposta ultrapassa o orçamento. Podes baixar o valor ou pedir o jogador emprestado.</div>` : ""}
    <div class="nm-kv"><span>Valor de mercado</span><b>${fmtMoney(c.marketValue)}</b></div>
    <div class="nm-kv"><span>Pedido estimado do clube</span><b>${fmtMoney(c.estimate)}</b></div>
    <div class="nm-kv"><span>Fase da carreira</span><b>${escapeHtml(careerStage(c.player).label)}</b></div>`;
}
function nmStepClubeHtml(){
  const c = nmCtx;
  if(c.tab === "emprestimo") return nmLoanHtml();
  const key = transferNegotiationKey(c.player, c.fromTeam, c.toTeam);
  const session = (state.transferNegotiations || {})[key];
  if(session && session.estado === "pendente"){
    return `<div class="nm-box"><div class="nm-note ok">Proposta de ${fmtMoney(session.ultimaProposta || 0)} enviada ao ${escapeHtml(c.fromTeam.name)} — resposta prevista para ${fmtDateShort(new Date(session.pendingResponseDate + "T00:00:00Z"))}.</div></div>`;
  }
  const max = nmClubMax();
  const pct = (v) => Math.max(0, Math.min(100, v / max * 100));
  const budget = (c.toTeam.financeiro && c.toTeam.financeiro.orcamentoTransferencias) || 0;
  const markers = `<div class="nm-mk" style="left:${pct(c.marketValue)}%">Valor de mercado<i></i></div>
    <div class="nm-mk" style="left:${pct(c.estimate)}%;${Math.abs(pct(c.estimate) - pct(c.marketValue)) < 14 ? "top:auto;bottom:-44px;" : ""}">Pedido do clube<i></i></div>
    <div class="nm-mk b" style="left:${pct(Math.min(budget, max))}%"><i></i>O teu orçamento</div>`;
  return `<div class="nm-grid">
    <div class="nm-box">
      <h2>A tua proposta ao ${escapeHtml(c.fromTeam.name)}</h2>
      <div class="nm-row"><button class="nm-adj" data-nm="valor-" aria-label="Menos">−</button><div class="nm-big"><span id="nmBig">${fmtMoney(c.valor)}</span></div><button class="nm-adj" data-nm="valor+" aria-label="Mais">+</button><span class="nm-mini">passos de 500 €</span></div>
      <div class="nm-railwrap">${nmRailHtml(pct(c.valor), markers, "nmFill")}<input type="range" class="nm-range" id="nmRange" min="0" max="${max}" step="500" value="${Math.min(c.valor, max)}"></div>
      <div class="nm-chips">
        <button class="nm-chip" data-nm="preset" data-v="0.9">Pedido −10%</button>
        <button class="nm-chip" data-nm="preset" data-v="1">Igual ao pedido</button>
        <button class="nm-chip" data-nm="preset" data-v="1.1">Pedido +10%</button>
      </div>
      <div class="nm-mini" style="margin-top:12px">${session && session.rondaClube ? `Ronda ${session.rondaClube} · última proposta ${fmtMoney(session.ultimaProposta || 0)} · ` : ""}o clube responde em 1 a 4 dias.</div>
    </div>
    <div class="nm-box" id="nmImpact">${nmClubImpactHtml()}</div>
  </div>`;
}

// ----- passo 1 (alternativa): empréstimo -----
function nmLoanHtml(){
  const c = nmCtx;
  const session = nmLoanNote(c.player, c.fromTeam, c.toTeam);
  if(session && session.estado === "pendente"){
    return `<div class="nm-box"><div class="nm-note ok">Pedido de empréstimo enviado — resposta prevista para ${fmtDateShort(new Date(session.responseDate + "T00:00:00Z"))}.</div></div>`;
  }
  if(session && session.estado === "jogador-a-decidir"){
    return `<div class="nm-box"><div class="nm-note ok">O clube aceitou o empréstimo — a aguardar a decisão do jogador (resposta prevista para ${fmtDateShort(new Date(session.playerResponseDate + "T00:00:00Z"))}).</div></div>`;
  }
  const check = canLoanPlayer(c.player, c.fromTeam, c.toTeam);
  const refusalNote = session && session.estado === "recusada-jogador"
    ? `<div class="nm-note warn">❌ O jogador recusou o empréstimo anterior${session.motivoJogador ? `: ${escapeHtml(session.motivoJogador)}` : ""}.</div>` : "";
  const counterNote = session && session.estado === "clube" && session.counter
    ? `<div class="nm-note warn">↩️ Contraproposta anterior do clube: ${session.counter.salaryShare}% do salário, papel ${escapeHtml(ROLE_LABELS[session.counter.role] || session.counter.role)}, ${escapeHtml(empClausulasTexto(session.counter.clausulas))}.</div>` : "";
  if(!check.ok){
    return `<div class="nm-box"><h2>Pedir emprestado por uma época</h2><div class="nm-note warn">${escapeHtml(check.reason)}</div></div>`;
  }
  const shares = [0, 25, 50, 75, 100];
  return `<div class="nm-grid">
    <div class="nm-box">
      <h2>Salário suportado pelo teu clube</h2>
      <div class="nm-chips">${shares.map(s => `<button class="nm-chip ${c.share === s ? "on" : ""}" data-nm="share" data-v="${s}">${s}%</button>`).join("")}</div>
      <h2 style="margin-top:16px">Papel no plantel</h2>
      <div class="nm-chips">${PLAYER_ROLES.map(r => `<button class="nm-chip ${c.loanRole === r ? "on" : ""}" data-nm="lrole" data-v="${r}">${escapeHtml(ROLE_LABELS[r])}</button>`).join("")}</div>
      ${counterNote}${refusalNote}
      <details class="nm-details"><summary>Cláusulas (opcional)</summary>${empEditorHtml(c.player, c.fromTeam, session && session.counter ? session.counter.clausulas : null)}</details>
    </div>
    <div class="nm-box" id="nmImpact">${nmLoanImpactHtml()}</div>
  </div>`;
}
function nmLoanImpactHtml(){
  const c = nmCtx;
  const sal = (c.player.contrato && c.player.contrato.salarioMensal) || 0;
  const mine = Math.round(sal * c.share / 100);
  return `<h2>O que isto custa ao clube</h2>
    <div class="nm-kv"><span>Salário atual do jogador</span><b>${fmtMoney(sal)}/mês</b></div>
    <div class="nm-kv"><span>A cargo do teu clube (${c.share}%)</span><b class="y">${fmtMoney(mine)}/mês</b></div>
    <div class="nm-kv"><span>Durante a época (12 meses)</span><b>${fmtMoney(mine * 12)}</b></div>
    <div class="nm-kv"><span>Orçamento de transferências</span><b>${fmtMoney((c.toTeam.financeiro && c.toTeam.financeiro.orcamentoTransferencias) || 0)}</b></div>
    <div class="nm-kv"><span>Aceitação do jogador (previsão)</span><b>${loanConsentHintHtml(c.player, c.fromTeam, c.toTeam, c.share, c.loanRole)}</b></div>
    <div class="nm-note">O empréstimo não gasta orçamento de transferências — só salário. O jogador tem de aceitar: decide em 1 a 3 dias.</div>`;
}

// ----- passo 2: jogador -----
function nmContratoImpactHtml(){
  const c = nmCtx;
  const fee = (c.kind === "transferencia" && c.fromTeam && c.fromTeam.id !== c.toTeam.id) ? (c.fee != null ? c.fee : (agreedTransferFee(c.player, c.fromTeam, c.toTeam) || 0)) : 0;
  const wages = c.salario * 12 * c.anos;
  const total = fee + wages;
  const bill = monthlyWageBill(c.toTeam) || 0;
  const peso = bill > 0 ? Math.round(c.salario / bill * 1000) / 10 : null;
  const ctx = (c.kind !== "renovacao" && typeof scoutingClubPositionalContext === "function") ? scoutingClubPositionalContext(c.toTeam, c.player.pos, c.player.linha) : null;
  const pos = ctx ? `${ctx.count} no plantel · melhor OVR ${ctx.melhor}` : null;
  return `<h2>O que isto custa ao clube</h2>
    ${fee ? `<div class="nm-kv"><span>Transferência</span><b>${fmtMoney(fee)}</b></div>` : ""}
    <div class="nm-kv"><span>Salários (${c.anos} ${c.anos === 1 ? "ano" : "anos"})</span><b>${fmtMoney(wages)}</b></div>
    <div class="nm-kv"><span>Compromisso total</span><b class="y">${fmtMoney(total)}</b></div>
    ${peso != null ? `<div class="nm-kv"><span>Peso na folha salarial</span><b>${c.kind === "renovacao" ? "" : "+"}${peso}%</b></div>` : ""}
    ${pos ? `<div class="nm-kv"><span>Nesta posição</span><b>${escapeHtml(pos)}</b></div>` : ""}`;
}
function nmStepJogadorHtml(){
  const c = nmCtx;
  const session = (state.contractNegotiations || {})[negotiationSessionKey(c.kind, c.player, c.fromTeam, c.toTeam)];
  if(session && session.aguardaResposta){
    return `<div class="nm-box"><div class="nm-note ok">Proposta enviada — resposta prevista para ${fmtDateShort(new Date(session.pendingResponseDate + "T00:00:00Z"))}.</div></div>`;
  }
  const maxSal = Math.max(1500, nmRound(c.salarioSug * 2.5, 50));
  const pct = (v) => Math.max(0, Math.min(100, v / maxSal * 100));
  const notes = [];
  if(c.counter) notes.push(`<div class="nm-note warn">↩️ Contraproposta do jogador: ${fmtMoney(c.counter.salarioMensal)}/mês, ${c.counter.anos} ano(s), papel ${escapeHtml(ROLE_LABELS[c.counter.papel] || c.counter.papel)}. O formulário já está preenchido com esses valores.</div>`);
  if(c.fromTeam && c.fromTeam.id !== c.toTeam.id && (clubAppeal(c.fromTeam) - clubAppeal(c.toTeam)) > DOWNSTEP_APPEAL_NOTE_THRESHOLD){
    notes.push(`<div class="nm-note warn">⚠️ Vem de um clube maior — só assina aqui por um salário bem acima do habitual para o seu nível.</div>`);
  }
  if(isPlayerDisplaced(c.player, c.toTeam)){
    notes.push(`<div class="nm-note warn">🌍 Jogador deslocado do país de origem — exige salário mais alto por estar longe da família, e o clube pagará ainda ${fmtMoney(playerHousingCost(c.player))}/mês de alojamento.</div>`);
  }
  return `<div class="nm-grid">
    <div class="nm-box">
      <h2>Salário mensal</h2>
      <div class="nm-row"><button class="nm-adj" data-nm="sal-" aria-label="Menos">−</button><div class="nm-big"><span id="nmBig">${fmtMoney(c.salario)}</span><small> / mês</small></div><button class="nm-adj" data-nm="sal+" aria-label="Mais">+</button></div>
      <div class="nm-railwrap" style="margin-bottom:20px">${nmRailHtml(pct(c.salario), `<div class="nm-mk" style="left:${pct(c.salarioSug)}%">${c.counter ? "Contraproposta" : "Pedido estimado"}<i></i></div>`, "nmFill")}<input type="range" class="nm-range" id="nmRange" min="0" max="${maxSal}" step="50" value="${Math.min(c.salario, maxSal)}"></div>
      <h2>Duração</h2>
      <div class="nm-seg">${[1, 2, 3].map(n => `<button class="${c.anos === n ? "on" : ""}" data-nm="anos" data-v="${n}">${n} ${n === 1 ? "ano" : "anos"}</button>`).join("")}</div>
      <h2 style="margin-top:16px">Papel no plantel</h2>
      <div class="nm-chips">${PLAYER_ROLES.map(r => `<button class="nm-chip ${c.papel === r ? "on" : ""}" data-nm="papel" data-v="${r}">${escapeHtml(ROLE_LABELS[r])}</button>`).join("")}</div>
      ${notes.join("")}
    </div>
    <div class="nm-box" id="nmImpact">${nmContratoImpactHtml()}</div>
  </div>`;
}

// ----- passo 3: confirmação -----
function nmStepConfirmarHtml(){
  const e = nmCtx.enviado || {};
  return `<div class="nm-box nm-sent"><div class="nm-sent-i">✅</div><h2 style="margin:6px 0">${escapeHtml(e.titulo || "Proposta enviada")}</h2>
    <p>${escapeHtml(e.texto || "")}</p>
    ${e.responseDate ? `<p class="nm-mini">Resposta prevista para <b>${fmtDateShort(new Date(e.responseDate + "T00:00:00Z"))}</b>. Vais receber um email com a resposta.</p>` : ""}</div>`;
}

// ----- rodapé -----
function nmFooterHtml(){
  const c = nmCtx;
  const err = c.erro ? `<div class="nm-err">Recusado: ${escapeHtml(c.erro)}</div>` : "";
  if(c.step === "confirmar") return `<div class="nm-foot"><button class="nm-btn p" data-nm="close">Fechar</button></div>`;
  if(c.step === "clube"){
    const loan = c.tab === "emprestimo";
    const sum = loan ? `Empréstimo · <b>${c.share}%</b> do salário · <b>${escapeHtml(ROLE_LABELS[c.loanRole])}</b>` : `Proposta: <b id="nmSumV">${fmtMoney(c.valor)}</b> · transferência definitiva`;
    return `${err}<div class="nm-foot"><div class="nm-sum">${sum}</div><button class="nm-btn p" data-nm="${loan ? "send-loan" : "send-club"}">${loan ? "Pedir empréstimo →" : "Enviar ao clube →"}</button></div>`;
  }
  const back = c.steps[0] === "clube" ? `<button class="nm-btn" data-nm="back">← Voltar ao clube</button>` : "";
  return `${err}<div class="nm-foot">${back}<div class="nm-sum" id="nmSum">Contrato: <b>${fmtMoney(c.salario)}/mês</b> · <b>${c.anos} ${c.anos === 1 ? "ano" : "anos"}</b> · <b>${escapeHtml(ROLE_LABELS[c.papel])}</b></div><button class="nm-btn p" data-nm="send-contrato">Enviar ao jogador →</button></div>`;
}

function nmRender(){
  const c = nmCtx; if(!c) return;
  const body = c.step === "clube" ? nmStepClubeHtml() : c.step === "jogador" ? nmStepJogadorHtml() : nmStepConfirmarHtml();
  const box = document.getElementById("nmBox"); if(!box) return;
  box.innerHTML = `${nmHeaderHtml()}${c.step === "confirmar" ? "" : nmStepperHtml()}${body}${nmFooterHtml()}`;
}

// Atualização parcial (sem reconstruir a janela, para não largar o cursor do slider).
function nmLive(){
  const c = nmCtx; if(!c) return;
  const big = document.getElementById("nmBig");
  const imp = document.getElementById("nmImpact");
  const fill = document.getElementById("nmFill");
  const range = document.getElementById("nmRange");
  if(c.step === "clube" && c.tab === "comprar"){
    if(big) big.textContent = fmtMoney(c.valor);
    if(imp) imp.innerHTML = nmClubImpactHtml();
    const max = nmClubMax(); if(fill) fill.style.width = Math.max(0, Math.min(100, c.valor / max * 100)) + "%";
    const sv = document.getElementById("nmSumV"); if(sv) sv.textContent = fmtMoney(c.valor);
  } else if(c.step === "jogador"){
    if(big) big.textContent = fmtMoney(c.salario);
    if(imp) imp.innerHTML = nmContratoImpactHtml();
    const maxSal = Math.max(1500, nmRound(c.salarioSug * 2.5, 50)); if(fill) fill.style.width = Math.max(0, Math.min(100, c.salario / maxSal * 100)) + "%";
    const sum = document.getElementById("nmSum"); if(sum) sum.innerHTML = `Contrato: <b>${fmtMoney(c.salario)}/mês</b> · <b>${c.anos} ${c.anos === 1 ? "ano" : "anos"}</b> · <b>${escapeHtml(ROLE_LABELS[c.papel])}</b>`;
  }
  if(range){ const v = c.step === "clube" ? c.valor : c.salario; if(parseInt(range.value, 10) !== v) range.value = v; }
}

function nmOnInput(e){
  const c = nmCtx; if(!c) return;
  if(e.target && e.target.id === "nmRange"){
    const v = parseInt(e.target.value, 10) || 0;
    if(c.step === "clube") c.valor = Math.max(0, v); else c.salario = Math.max(c.salFloor||0, v);
    c.erro = "";
    nmLive();
  }
}

function nmOnClick(e){
  const c = nmCtx; if(!c) return;
  if(e.target.classList && e.target.classList.contains("nm-overlay")){ nmClose(); return; }
  const el = e.target.closest("[data-nm]"); if(!el) return;
  const act = el.getAttribute("data-nm"), v = el.getAttribute("data-v");
  switch(act){
    case "close": nmClose(); return;
    case "tab": c.tab = v; c.erro = ""; nmRender(); return;
    case "back": c.step = "clube"; c.erro = ""; nmRender(); return;
    case "valor-": c.valor = Math.max(0, c.valor - 500); c.erro = ""; nmLive(); return;
    case "valor+": c.valor = c.valor + 500; c.erro = ""; nmLive(); return;
    case "sal-": c.salario = Math.max(c.salFloor||0, c.salario - 50); c.erro = ""; nmLive(); return;
    case "sal+": c.salario = c.salario + 50; c.erro = ""; nmLive(); return;
    case "preset": c.valor = Math.max(0, nmRound(c.estimate * parseFloat(v), 500)); c.erro = ""; nmLive(); return;
    case "share": c.share = parseInt(v, 10); c.erro = ""; nmRender(); return;
    case "lrole": c.loanRole = v; c.erro = ""; nmRender(); return;
    case "anos": c.anos = parseInt(v, 10); c.erro = ""; nmRender(); return;
    case "papel": c.papel = v; c.erro = ""; nmRender(); return;
    case "send-club": {
      const r = negotiateWithClub(c.player.id, c.fromTeam.id, c.toTeam.id, Math.max(0, c.valor));
      if(r.outcome === "pendente"){
        c.enviado = { titulo: "Proposta enviada ao clube", texto: `${fmtMoney(c.valor)} ao ${c.fromTeam.name}.`, responseDate: r.responseDate };
        c.step = "confirmar"; c.erro = ""; nmRender();
      } else { c.erro = r.reason || "sem interesse"; nmRender(); }
      return;
    }
    case "send-loan": {
      const root = document.getElementById("nmBox");
      const r = proposeLoan(c.player.id, c.fromTeam.id, c.toTeam.id, c.share, c.loanRole, empLerClausulas(root));
      if(r.outcome === "pendente"){
        c.enviado = { titulo: "Pedido de empréstimo enviado", texto: `${c.share}% do salário a teu cargo, papel ${ROLE_LABELS[c.loanRole]}.`, responseDate: r.responseDate };
        c.step = "confirmar"; c.erro = ""; nmRender();
      } else { c.erro = r.reason || "sem interesse"; nmRender(); }
      return;
    }
    case "send-contrato": {
      const offer = { salarioMensal: Math.max(c.salFloor||0, c.salario), anos: c.anos, papel: c.papel };
      const r = proposeContract(c.kind, c.player.id, c.fromTeam ? c.fromTeam.id : null, c.toTeam.id, offer);
      if(r.outcome === "pendente"){
        c.enviado = { titulo: "Proposta enviada ao jogador", texto: `${fmtMoney(offer.salarioMensal)}/mês, ${offer.anos} ${offer.anos === 1 ? "ano" : "anos"}, papel ${ROLE_LABELS[offer.papel]}.`, responseDate: r.responseDate };
        c.step = "confirmar"; c.erro = ""; nmRender();
      } else { c.erro = r.reason || "sem interesse"; nmRender(); }
      return;
    }
  }
}
