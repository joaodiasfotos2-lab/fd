// Jogadores à experiência + relatório completo do adjunto (2026-10-11, pedido do utilizador:
// ideia 4 da quarta lista de ideias, com o pedido "deve ser possível pedir um relatório ao
// treinador adjunto completo com conclusões: vale a pena contratar?").
// Decisões de desenho confirmadas por ele:
//  - só JOGADORES LIVRES; uma semana (5 a 7 dias) a treinar com o plantel; custo pequeno
//    (alojamento e seguro); no máximo 2 em simultâneo;
//  - no fim, os atributos do jogador passam a ser exatos para o utilizador e este pode assinar
//    (pelo cartão normal do jogador livre) ou deixá-lo ir;
//  - o adjunto entrega um relatório completo com conclusões: veredito claro (contratar /
//    contratar com reservas / não contratar), riscos, custos e condições, e ainda o encaixe no
//    plantel e no sistema (o veredito depende disso).
//
// Dados (tudo no próprio jogador livre, que já é guardado nos saves):
//   player.experiencia = { equipaId, inicio, fim, dias, custo, concluida, resolvidaEm, decisao,
//                          relatorio }
//   player.lesoesGraves  contador de lesões graves de carreira (escrito por applyInjuryOutcome)
//
// Sem experiência, um jogador livre mostra-se com o nevoeiro de scouting habitual (antes o OVR
// dos livres era sempre exato, ao contrário dos jogadores de outros clubes).

const EXP_MAX_SIMULTANEAS = 2;
const EXP_DIAS_MIN = 5;
const EXP_DIAS_MAX = 7;
const EXP_CUSTO_DIA = 90; // alojamento + seguro, por dia

function experienciaAtiva(p){ return !!(p && p.experiencia && !p.experiencia.concluida); }
function experienciaConcluida(p){ return !!(p && p.experiencia && p.experiencia.concluida); }
// A experiência só torna exatos os atributos para o clube que a fez.
function experienciaExataParaUtilizador(p){
  return !!(p && p.experiencia && p.experiencia.concluida && p.experiencia.equipaId === state.userTeamId);
}
function experienciasEmCurso(){
  return (state.freeAgents || []).filter(p => experienciaAtiva(p) && p.experiencia.equipaId === state.userTeamId);
}
function experienciaCustoTotal(dias){ return dias * EXP_CUSTO_DIA; }

// OVR mostrado de um jogador livre: exato depois da experiência, estimativa com nevoeiro antes.
function experienciaOvrVisivel(p){
  if(experienciaExataParaUtilizador(p)) return overall(p);
  return visibleOverall(p, { id: "agente-livre" });
}

function experienciaPodeIniciar(team, p){
  if(!team || !p) return { ok: false, reason: "Jogador inválido." };
  if(!(state.freeAgents || []).some(x => x.id === p.id)) return { ok: false, reason: "Este jogador já não está livre." };
  if(p.experiencia) return { ok: false, reason: experienciaAtiva(p) ? "Já está à experiência." : "Já fez a experiência." };
  if(playerHasPendingDeal(p)) return { ok: false, reason: "Tem uma negociação em curso." };
  if(experienciasEmCurso().length >= EXP_MAX_SIMULTANEAS) return { ok: false, reason: `Já tens ${EXP_MAX_SIMULTANEAS} jogadores à experiência — espera que um termine.` };
  const custo = experienciaCustoTotal(EXP_DIAS_MAX);
  initClubFinance(team);
  if((team.financeiro.saldo || 0) < custo) return { ok: false, reason: `Saldo insuficiente para o alojamento e seguro (até ${fmtMoney(custo)}).` };
  return { ok: true };
}

function iniciarExperiencia(team, playerId){
  const p = (state.freeAgents || []).find(x => x.id === playerId);
  const chk = experienciaPodeIniciar(team, p);
  if(!chk.ok) return chk;
  const dias = EXP_DIAS_MIN + Math.floor(Math.random() * (EXP_DIAS_MAX - EXP_DIAS_MIN + 1));
  const custo = experienciaCustoTotal(dias);
  const inicio = new Date(state.currentDate);
  p.experiencia = { equipaId: team.id, inicio: isoDate(inicio), fim: isoDate(addDays(inicio, dias)), dias, custo, concluida: false, resolvidaEm: null, decisao: null, relatorio: null };
  addFinanceMovement(team, "despesa", "Estrutura", `Experiência de ${p.name} (${dias} dias): alojamento e seguro`, custo, state.currentDate);
  return { ok: true, dias, custo, fim: p.experiencia.fim };
}

// ----------------------------------------------------------------------------------------------
// Relatório do adjunto
// ----------------------------------------------------------------------------------------------
function expGrupoDoJogador(team, p){
  const mesmo = x => p.pos === "GR" ? x.pos === "GR" : (x.pos !== "GR" && x.linha === p.linha);
  return (team.players || []).filter(x => !x.emprestimo && mesmo(x)).sort((a, b) => overall(b) - overall(a));
}
function expAnosRecomendados(p){
  if(p.age >= 33) return 1;
  if(p.age <= 23 && p.potential - overall(p) >= 3) return 3;
  return 2;
}
function expPotLabel(p){
  const m = p.potential - overall(p);
  return m <= 1 ? "Limitada" : m <= 3 ? "Regular" : m <= 5 ? "Interessante" : m <= 7 ? "Elevada" : "Excecional";
}
function buildExperienciaRelatorio(team, p){
  const ovr = overall(p);
  const grupo = expGrupoDoJogador(team, p);
  const ehGR = p.pos === "GR";
  const nTit = ehGR ? 1 : (p.linha === "Avancado" ? 2 : 3);
  const refTit = grupo[nTit - 1] || grupo[grupo.length - 1] || null;
  const refOvr = refTit ? overall(refTit) : 0;
  const gap = refTit ? ovr - refOvr : 99;
  const melhorAtual = grupo[0] || null;
  const fatores = []; // { txt, pts }

  // 1) Encaixe desportivo
  let encaixeTxt, lugar;
  if(!refTit){ encaixeTxt = "O plantel não tem ninguém nesta posição — seria titular imediato."; lugar = "titular"; fatores.push({ txt: "Preenche uma posição sem opções no plantel", pts: 3 }); }
  else if(gap >= 2){ encaixeTxt = `Fica claramente acima dos titulares da posição (${refTit.name}, OVR ${refOvr}, é o último a entrar no onze). Seria reforço imediato.`; lugar = "titular"; fatores.push({ txt: "É um reforço claro para o onze", pts: 3 }); }
  else if(gap >= 0.5){ encaixeTxt = `Disputa o lugar de titular: está ligeiramente acima de ${refTit.name} (OVR ${refOvr}).`; lugar = "disputa"; fatores.push({ txt: "Disputa um lugar no onze e sobe a concorrência interna", pts: 2 }); }
  else if(gap >= -1){ encaixeTxt = `Seria opção de rotação, muito perto do nível de ${refTit.name} (OVR ${refOvr}).`; lugar = "rotacao"; fatores.push({ txt: "Daria profundidade, mas sem subir o onze", pts: 0.5 }); }
  else { encaixeTxt = `Fica abaixo do nível dos titulares da posição (${refTit.name}, OVR ${refOvr}) — não acrescenta ao onze.`; lugar = "suplente"; fatores.push({ txt: "Não melhora o onze (nível abaixo dos titulares)", pts: -1.5 }); }
  if(grupo.length < nTit + 1){ fatores.push({ txt: "A posição está curta de opções no plantel", pts: 1 }); }

  // 2) Encaixe no sistema (diferença na adequação do sistema atual com e sem o jogador)
  let fitAntes = 0, fitDepois = 0;
  try {
    fitAntes = systemFitScore(team, team.sistema || "3-1");
    team.players.push(p);
    try { fitDepois = systemFitScore(team, team.sistema || "3-1"); } finally { team.players.pop(); }
  } catch(e){ fitDepois = fitAntes; }
  const fitDelta = Math.round((fitDepois - fitAntes) * 10) / 10;
  const sistemaTxt = fitDelta >= 3 ? `Melhora de forma notória a adequação ao ${team.sistema || "3-1"} (+${fitDelta.toFixed(1)}).`
    : fitDelta >= 1 ? `Melhora a adequação ao ${team.sistema || "3-1"} (+${fitDelta.toFixed(1)}).`
    : "Praticamente não altera a adequação ao sistema atual.";
  if(fitDelta >= 3) fatores.push({ txt: `Encaixa muito bem no ${team.sistema || "3-1"}`, pts: 1.5 });
  else if(fitDelta >= 1) fatores.push({ txt: `Ajuda no ${team.sistema || "3-1"}`, pts: 0.5 });

  // 3) Custos e condições
  initClubFinance(team);
  const f = team.financeiro;
  const papel = assignInitialRole(ovr, p.age, p.potential, false);
  const salario = Math.round(freeAgentSalaryDemand(p, team, papel) / 50) * 50;
  const anos = expAnosRecomendados(p);
  const massa = monthlyWageBill(team);
  const limite = f.limiteSalarial || 0;
  const folga = Math.max(0, limite - massa);
  const alojamento = isPlayerDisplaced(p, team) ? playerHousingCost(p) : 0;
  const custoMensal = salario + alojamento;
  const medGrupo = grupo.slice(0, nTit).map(x => (x.contrato && x.contrato.salarioMensal) || 0).filter(v => v > 0);
  const mediaTit = medGrupo.length ? medGrupo.reduce((a, b) => a + b, 0) / medGrupo.length : 0;
  let bloqueio = null;
  if(custoMensal > folga){ bloqueio = `O salário esperado (${fmtMoney(custoMensal)}/mês) ultrapassa a folga do limite salarial (${fmtMoney(folga)}).`; fatores.push({ txt: "Não cabe no limite salarial do clube", pts: -3 }); }
  else if(folga > 0 && custoMensal > folga * 0.4){ fatores.push({ txt: `Consome ${Math.round(custoMensal / folga * 100)}% da folga salarial`, pts: -0.5 }); }
  if(mediaTit > 0){
    const r = salario / mediaTit;
    if(r > 1.4) fatores.push({ txt: "Pede bem acima do que ganham os titulares da posição", pts: -1.5 });
    else if(r > 1.15) fatores.push({ txt: "Pede um pouco acima do que ganham os titulares da posição", pts: -0.5 });
    else if(r <= 0.9) fatores.push({ txt: "Pede menos do que ganham os titulares da posição", pts: 1 });
  }

  // Alternativas no mercado de livres (mesma posição, nível semelhante ou melhor)
  const alternativas = (state.freeAgents || [])
    .filter(x => x.id !== p.id && x.pos === p.pos && (ehGR || x.linha === p.linha) && experienciaOvrVisivel(x) >= ovr - 1)
    .map(x => { const role = assignInitialRole(overall(x), x.age, x.potential, false); return { nome: x.name, idade: x.age, ovr: experienciaOvrVisivel(x), exato: experienciaExataParaUtilizador(x), salario: Math.round(freeAgentSalaryDemand(x, team, role) / 50) * 50 }; })
    .sort((a, b) => b.ovr - a.ovr || a.salario - b.salario).slice(0, 3);

  // 4) Riscos
  const riscos = [];
  const etapa = careerStage(p);
  if(etapa.id === "final"){ riscos.push({ nivel: "alto", titulo: "Fase de carreira", texto: `${p.age} anos, em final de carreira: o desgaste físico pode comprometer o rendimento já na segunda metade do contrato.` }); fatores.push({ txt: "Final de carreira", pts: -1 }); }
  else if(etapa.id === "declinio"){ riscos.push({ nivel: "medio", titulo: "Fase de carreira", texto: `${p.age} anos, já em declínio: espera-se estabilidade, não crescimento. Contratos curtos protegem o clube.` }); fatores.push({ txt: "Já em declínio físico", pts: -0.5 }); }
  else if(etapa.id === "inicio"){ riscos.push({ nivel: p.potential - ovr >= 3 ? "baixo" : "medio", titulo: "Fase de carreira", texto: `${p.age} anos, ainda no início de carreira: ${p.potential - ovr >= 3 ? "há margem de progressão real, mas sem garantias de regularidade" : "a margem de progressão parece curta"}.` }); if(p.potential - ovr >= 3) fatores.push({ txt: "Tem margem real de progressão", pts: 0.5 }); }
  else riscos.push({ nivel: "baixo", titulo: "Fase de carreira", texto: `${p.age} anos, no auge: sem riscos de curva de idade no horizonte do contrato.` });

  const graves = p.lesoesGraves || 0, resist = (p.attrs && p.attrs.resistencia) || 12;
  if((p.diasLesao || 0) > 0){ riscos.push({ nivel: "alto", titulo: "Estado físico", texto: `Está lesionado neste momento (${p.diasLesao} dias de paragem) — não ajudaria de imediato.` }); fatores.push({ txt: "Lesionado neste momento", pts: -1 }); }
  else if(graves >= 2){ riscos.push({ nivel: "alto", titulo: "Historial de lesões", texto: `Teve ${graves} lesões graves na carreira — é um jogador de risco clínico.` }); fatores.push({ txt: "Historial de lesões graves", pts: -1 }); }
  else if(graves === 1){ riscos.push({ nivel: "medio", titulo: "Historial de lesões", texto: "Já teve uma lesão grave na carreira — convém reforçar a gestão de carga." }); }
  else if(resist < 11){ riscos.push({ nivel: "medio", titulo: "Estado físico", texto: `Resistência baixa (${resist}): vai ter dificuldade em manter o ritmo em jogos intensos e é mais exposto a quebras.` }); }
  else riscos.push({ nivel: "baixo", titulo: "Estado físico", texto: "Sem historial de lesões graves conhecido e com resistência adequada." });

  const tr = persTraco(p), temp = persLabelDe(tr);
  const compete = lugar === "rotacao" || lugar === "suplente";
  if((tr === "instavel" || tr === "ambicioso") && compete){ riscos.push({ nivel: "alto", titulo: "Personalidade", texto: `${temp}: se não for titular, tende a descontentar-se depressa e a perder moral no banco.` }); fatores.push({ txt: `Personalidade ${temp.toLowerCase()} sem lugar garantido`, pts: -0.5 }); }
  else if(tr === "instavel") riscos.push({ nivel: "medio", titulo: "Personalidade", texto: "Instável: rendimento irregular, mais cartões e moral sensível a maus resultados." });
  else if(tr === "ambicioso") riscos.push({ nivel: "medio", titulo: "Personalidade", texto: "Ambicioso: exige lugar no onze e pede ser tratado como tal." });
  else if(tr === "lider") riscos.push({ nivel: "baixo", titulo: "Personalidade", texto: "Líder: ajuda a química do balneário e lida bem com a rotação." });
  else riscos.push({ nivel: "baixo", titulo: "Personalidade", texto: "Leal ao clube: perfil estável, lida bem com a rotação." });

  let balTxt, balNivel = "baixo";
  const incumbentes = lugar === "titular" || lugar === "disputa" ? grupo.slice(Math.max(0, nTit - 1), nTit + 0) : [];
  const b = typeof ensureBalneario === "function" ? ensureBalneario(team) : null;
  const frag = b && b.coesao < 46;
  if(incumbentes.length && refTit){
    balNivel = frag ? "alto" : "medio";
    balTxt = `Tira o lugar a ${refTit.name}${frag ? ", num balneário que já está fragilizado — a mudança pode pesar" : " — vai haver que gerir a reação de quem perde o lugar"}.`;
    if(frag) fatores.push({ txt: "Entrada com impacto num balneário frágil", pts: -0.5 });
  } else if(frag){ balNivel = "medio"; balTxt = "O balneário está fragilizado; uma chegada sem lugar claro não ajuda."; }
  else balTxt = "Sem impacto relevante esperado no balneário.";
  const lid = (p.attrs && p.attrs.lideranca) || 10;
  if(lid >= 15) balTxt += ` Tem peso de liderança (${lid}) — pode ajudar o grupo.`;
  riscos.push({ nivel: balNivel, titulo: "Balneário", texto: balTxt });

  // 5) Veredito
  const pontos = fatores.reduce((s, x) => s + x.pts, 0);
  let id = pontos >= 3 ? "contratar" : pontos >= 1 ? "reservas" : "nao";
  if(bloqueio) id = "nao";
  const label = { contratar: "Contratar", reservas: "Contratar com reservas", nao: "Não contratar" }[id];
  const positivos = fatores.filter(x => x.pts > 0).sort((a, c) => c.pts - a.pts);
  const negativos = fatores.filter(x => x.pts < 0).sort((a, c) => a.pts - c.pts);
  let motivo;
  if(bloqueio) motivo = bloqueio;
  else if(id === "contratar") motivo = (positivos[0] ? positivos[0].txt : "Reforço claro") + (negativos[0] ? `; a ter em conta: ${negativos[0].txt.toLowerCase()}` : "") + ".";
  else if(id === "reservas") motivo = `${positivos[0] ? positivos[0].txt : "Tem utilidade"}, mas ${negativos[0] ? negativos[0].txt.toLowerCase() : "há pontos por esclarecer"}.`;
  else motivo = (negativos[0] ? negativos[0].txt : "Não acrescenta ao plantel") + (positivos[0] ? `, apesar de ${positivos[0].txt.toLowerCase()}` : "") + ".";
  const caro = mediaTit > 0 && salario / mediaTit > 1.4;
  const compensa = bloqueio ? "Não cabe no orçamento salarial."
    : caro && (lugar === "titular" || lugar === "disputa") ? "O contributo desportivo justifica o interesse, mas o salário pedido é alto: só compensa se a negociação baixar a pedida ou se não houver alternativa melhor."
    : caro ? "O preço não compensa para o papel que teria."
    : lugar === "titular" || lugar === "disputa" ? "O preço compensa para o contributo esperado."
    : "Só compensa se o preço descer ou se for para dar profundidade.";

  // 6) Atributos (exatos: o adjunto viu-o treinar uma semana)
  const keys = SCOUTING_ATTR_LABELS[p.pos] || SCOUTING_ATTR_LABELS.J;
  const avals = keys.map(([key, lab]) => ({ label: lab, valor: Math.round(p.attrs[key]) })).sort((a, c) => c.valor - a.valor);

  return {
    data: isoDate(state.currentDate),
    nome: p.name, idade: p.age, pos: p.pos, linha: p.linha || null, ovr,
    potencial: expPotLabel(p),
    veredito: { id, label, motivo, compensa, pontos: Math.round(pontos * 10) / 10 },
    encaixe: { lugar, texto: encaixeTxt, sistema: sistemaTxt, fitDelta, referencia: refTit ? { nome: refTit.name, ovr: refOvr } : null, melhorAtual: melhorAtual ? { nome: melhorAtual.name, ovr: overall(melhorAtual) } : null },
    riscos,
    custos: { salario, alojamento, anos, papel, limite, massa, folga, mediaTitulares: Math.round(mediaTit), bloqueio, alternativas },
    fortes: avals.slice(0, 3), fracos: avals.slice(-2).reverse(),
  };
}

// ----------------------------------------------------------------------------------------------
// Fim da experiência (corre todos os dias)
// ----------------------------------------------------------------------------------------------
function resolverExperienciasDiarias(){
  const team = state.teams[state.userTeamId];
  if(!team || !Array.isArray(state.freeAgents)) return;
  const hoje = isoDate(state.currentDate);
  state.freeAgents.slice().forEach(p => {
    const e = p.experiencia;
    if(!e || e.concluida || e.equipaId !== state.userTeamId) return;
    if(e.fim > hoje) return;
    e.concluida = true; e.resolvidaEm = hoje;
    e.relatorio = buildExperienciaRelatorio(team, p);
    const r = e.relatorio;
    pushNews(state.currentDate,
      `O treinador adjunto concluiu a experiência de ${escapeHtml(p.name)} (${e.dias} dias a treinar com o plantel). Veredito: <b>${r.veredito.label}</b>. ${escapeHtml(r.veredito.motivo)} Relatório completo no Mercado, em jogadores livres.`,
      "scouting", `Relatório do adjunto: ${p.name}`, { autoAdvanceStop: true, teamId: team.id });
  });
}

// ----------------------------------------------------------------------------------------------
// Interface
// ----------------------------------------------------------------------------------------------
const EXP_NIVEL_COR = { baixo: "#3FA34D", medio: "#C98A00", alto: "#C0392B" };
const EXP_VEREDITO_COR = { contratar: "#3FA34D", reservas: "#C98A00", nao: "#C0392B" };

function experienciaRowHtml(p, team){
  const e = p.experiencia;
  const emCurso = experienciasEmCurso().length;
  if(!e){
    const chk = experienciaPodeIniciar(team, p);
    return `<div class="market-status exp-row" style="margin:-4px 0 10px;display:flex;gap:10px;align-items:center;flex-wrap:wrap;">
      <span class="helptext" style="margin:0;">OVR estimado — atributos por confirmar.</span>
      <button class="btn btn-ghost exp-start" data-player="${escapeHtml(p.id)}" ${chk.ok ? "" : "disabled"} title="${escapeHtml(chk.ok ? "" : chk.reason)}">Convidar para experiência (${EXP_DIAS_MIN}-${EXP_DIAS_MAX} dias · ~${fmtMoney(experienciaCustoTotal(6))})</button>
      ${chk.ok ? "" : `<span class="helptext" style="margin:0;">${escapeHtml(chk.reason)}</span>`}
    </div>`;
  }
  if(!e.concluida){
    const falta = Math.max(0, Math.round((new Date(e.fim + "T00:00:00Z") - new Date(isoDate(state.currentDate) + "T00:00:00Z")) / 86400000));
    return `<div class="market-status ok exp-row" style="margin:-4px 0 10px;">À experiência com o plantel — termina em ${fmtDateShort(new Date(e.fim + "T00:00:00Z"))} (faltam ${falta} dia${falta === 1 ? "" : "s"}). O adjunto prepara o relatório.</div>`;
  }
  const v = e.relatorio && e.relatorio.veredito;
  const cor = v ? EXP_VEREDITO_COR[v.id] : "#666";
  const dec = e.decisao === "dispensado" ? ' · <i>dispensado</i>' : "";
  return `<div class="market-status exp-row" style="margin:-4px 0 10px;display:flex;gap:10px;align-items:center;flex-wrap:wrap;">
    <span>Experiência concluída — atributos exatos${v ? ` · Veredito do adjunto: <b style="color:${cor};">${v.label}</b>` : ""}${dec}</span>
    <button class="btn btn-ghost exp-report" data-player="${escapeHtml(p.id)}">Ver relatório do adjunto</button>
    ${e.decisao === "dispensado" ? "" : `<button class="btn btn-ghost exp-dispensar" data-player="${escapeHtml(p.id)}">Dispensar</button>`}
  </div>`;
}

function experienciaHeaderHtml(){
  const n = experienciasEmCurso().length;
  return `<p class="helptext" style="margin:0 0 8px;">Jogadores à experiência: ${n}/${EXP_MAX_SIMULTANEAS}. Um jogador livre pode treinar uma semana com o plantel; no fim, o adjunto entrega um relatório com a conclusão sobre se vale a pena contratar. Os atributos dos livres são estimativas até lá.</p>`;
}

function renderExperienciaRelatorioHtml(r){
  const c = r.custos, enc = r.encaixe, v = r.veredito;
  const cor = EXP_VEREDITO_COR[v.id];
  const riscos = r.riscos.map(x => `<li><span style="color:${EXP_NIVEL_COR[x.nivel]};font-weight:700;">● ${x.nivel === "alto" ? "Risco alto" : x.nivel === "medio" ? "Risco médio" : "Risco baixo"}</span> <b>${escapeHtml(x.titulo)}:</b> ${escapeHtml(x.texto)}</li>`).join("");
  const alt = c.alternativas.length
    ? `<ul style="margin:4px 0 0 18px;">${c.alternativas.map(a => `<li>${escapeHtml(a.nome)} (${a.idade} anos, OVR ${a.exato ? "" : "~"}${a.ovr}) — cerca de ${fmtMoney(a.salario)}/mês</li>`).join("")}</ul>`
    : `<div class="helptext" style="margin:2px 0 0;">Não há outros jogadores livres comparáveis nesta posição neste momento.</div>`;
  const attr = a => `${escapeHtml(a.label)} ${a.valor}`;
  return `<div style="border-left:5px solid ${cor};padding:6px 12px;margin-bottom:12px;background:rgba(0,0,0,0.03);">
      <div style="font-size:12px;opacity:.7;">Veredito do adjunto — vale a pena contratar?</div>
      <div style="font-size:20px;font-weight:800;color:${cor};">${v.label}</div>
      <div style="margin-top:4px;">${escapeHtml(v.motivo)}</div>
      <div style="margin-top:4px;"><i>${escapeHtml(v.compensa)}</i></div>
    </div>
    <div class="eyebrow" style="margin:6px 0;">Perfil e encaixe</div>
    <p style="margin:0 0 4px;">${escapeHtml(r.nome)} · ${r.idade} anos · OVR ${r.ovr} · potencial de evolução: ${r.potencial}.</p>
    <p style="margin:0 0 4px;">Pontos fortes: ${r.fortes.map(attr).join(", ")}. Pontos fracos: ${r.fracos.map(attr).join(", ")}.</p>
    <p style="margin:0 0 4px;">${escapeHtml(enc.texto)}</p>
    <p style="margin:0 0 10px;">${escapeHtml(enc.sistema)}</p>
    <div class="eyebrow" style="margin:6px 0;">Riscos</div>
    <ul style="margin:0 0 10px 18px;">${riscos}</ul>
    <div class="eyebrow" style="margin:6px 0;">Custos e condições</div>
    <p style="margin:0 0 4px;">Salário esperado: <b>${fmtMoney(c.salario)}/mês</b>${c.alojamento ? ` (mais ${fmtMoney(c.alojamento)}/mês de alojamento)` : ""}. Contrato recomendado: <b>${c.anos} ano${c.anos > 1 ? "s" : ""}</b>, papel ${ROLE_LABELS[c.papel] || c.papel}.</p>
    <p style="margin:0 0 4px;">Limite salarial do clube: ${fmtMoney(c.limite)}/mês; massa atual ${fmtMoney(c.massa)}/mês; folga ${fmtMoney(c.folga)}/mês.${c.mediaTitulares ? ` Os titulares desta posição ganham em média ${fmtMoney(c.mediaTitulares)}/mês.` : ""}</p>
    <div style="margin:0 0 4px;">Alternativas no mercado de livres:${alt}</div>
    <div class="helptext" style="margin-top:8px;">Relatório de ${escapeHtml(r.data)}. Para contratar, usa a proposta no cartão do jogador; se não avançares, outro clube pode contratá-lo.</div>`;
}

function openExperienciaRelatorio(playerId){
  const p = (state.freeAgents || []).find(x => x.id === playerId);
  if(!p || !p.experiencia || !p.experiencia.relatorio){ showTransientNotice("Este relatório já não está disponível."); return; }
  const m = balnearioModalEl();
  m.querySelector("#balnearioModalTitle").textContent = `Relatório do adjunto — ${p.name}`;
  m.querySelector("#balnearioModalBody").innerHTML = `<div style="max-height:62vh;overflow:auto;">${renderExperienciaRelatorioHtml(p.experiencia.relatorio)}</div>`;
  m.classList.remove("hidden");
}

function refreshExperienciaUi(){
  if(typeof renderTransferMarket === "function") renderTransferMarket();
}

document.addEventListener("click", (e) => {
  const t = e.target;
  if(!t || !t.closest) return;
  const start = t.closest(".exp-start");
  if(start){
    const r = iniciarExperiencia(myTeam(), start.getAttribute("data-player"));
    if(r.ok) showTransientNotice(`Jogador convidado: fica ${r.dias} dias a treinar com o plantel (custo ${fmtMoney(r.custo)}).`);
    else showTransientNotice(r.reason);
    refreshExperienciaUi();
    return;
  }
  const rep = t.closest(".exp-report");
  if(rep){ openExperienciaRelatorio(rep.getAttribute("data-player")); return; }
  const dis = t.closest(".exp-dispensar");
  if(dis){
    const p = (state.freeAgents || []).find(x => x.id === dis.getAttribute("data-player"));
    if(p && p.experiencia) p.experiencia.decisao = "dispensado";
    refreshExperienciaUi();
  }
});

// Texto do OVR de um jogador livre: "~13" (estimativa) antes da experiência, "13" depois.
function experienciaOvrTexto(p){
  const v = experienciaOvrVisivel(p);
  return experienciaExataParaUtilizador(p) ? String(v) : `~${v}`;
}
