  // ============================= 07d-elite-cup.js =============================
  // Elite Cup — prova oficial de pré-época, eliminação direta a uma mão, sempre em campo neutro
  // (sem vantagem de jogar em casa), entre os 8 primeiros classificados do Campeonato Placard da
  // época anterior. Disputa-se antes da Supertaça António Livramento e antes da 1.ª jornada do
  // Campeonato Placard — importância oficial BAIXA (abaixo da Taça de Portugal e da Supertaça),
  // refletida sobretudo no prémio financeiro e no ganho de prestígio, sempre inferiores aos das
  // outras duas provas (ver ELITE_CUP_PRIZE_* / ELITE_CUP_PRESTIGE_WINNER abaixo).
  //
  // Ordem do calendário (roteiro): início da carreira/época → Elite Cup → Supertaça António
  // Livramento → Campeonato Placard. Em vez de fazer depender esta ordem de um novo ciclo
  // diário de "Continuar" (o que obrigaria a alterar profundamente o fluxo de defeso, hoje
  // atemporal — ver chooseClub/beginDefeso/finalizeNewSeason), a Elite Cup resolve-se de forma
  // comprimida: todas as eliminatórias que não envolvem o clube do utilizador são simuladas de
  // imediato (mesmo mecanismo já usado pela Taça de Portugal para os jogos IA-IA do dia), e o
  // fluxo só para mesmo quando chega a vez de o utilizador jogar — exatamente como a
  // convocatória interativa de qualquer outro jogo importante do jogo. As datas de cada fase
  // (sexta-feira quartos, sábado meias-finais, domingo final, ver eliteCupFaseDates) ficam
  // registadas para efeitos de histórico/interface, mesmo sem uma progressão dia-a-dia real.
  //
  // A 1.ª carreira de sempre não tem época anterior para apurar os 8 qualificados: usa-se a
  // classificação histórica fixa fornecida no roteiro de implementação.
  const ELITE_CUP_INITIAL_RANKING = ["benfica","sporting","porto","barcelos","braga","valongo","oliveirense","sanjoanense"];

  const ELITE_CUP_FASE_LABEL = { quartos:"Elite Cup — Quartos de Final", semifinal:"Elite Cup — Meias-Finais", final:"Elite Cup — Final" };
  // Tier atingido por quem é eliminado em cada fase (0 = só participou, 3 = venceu a final) —
  // usado para comparar com o nível do objetivo da direção (ver ELITE_CUP_LEVEL_TIER).
  const ELITE_CUP_FASE_ELIMINATION_TIER = { quartos:0, semifinal:1, final:2 };

  // Prémios e prestígio (parâmetros calibrados por simulação, tal como a Supertaça): o total
  // financeiro em jogo (vencedor + finalista + 2 meias-finalistas) e o ganho de prestígio do
  // campeão ficam sempre claramente abaixo dos equivalentes da Supertaça António Livramento
  // (50.000€/1,5 pontos) — a Elite Cup é a prova oficial de menor relevância do calendário.
  const ELITE_CUP_PRIZE_WINNER = 15000;
  const ELITE_CUP_PRIZE_RUNNERUP = 7000;
  const ELITE_CUP_PRIZE_SEMIFINALIST = 2500;
  const ELITE_CUP_PRESTIGE_WINNER = 0.8;

  // ---------------------------------------------------------------------------------------
  // Objetivos da direção (secção 11.4 do roteiro) — pesos e limiares centralizados aqui, para
  // calibração futura sem números mágicos espalhados pelo resto do módulo.
  // ---------------------------------------------------------------------------------------
  const ELITE_CUP_OBJECTIVE_WEIGHTS = Object.freeze({
    reputation: .30, squadStrength: .25, recentForm: .20, qualification: .10, squadDepth: .10, availability: .05,
  });
  // Ordem crescente de exigência — usada quer para escolher o nível a partir da pontuação, quer
  // para aplicar o ajuste (no máximo 1 nível) depois do sorteio.
  const ELITE_CUP_OBJECTIVE_LEVELS = ["competitivo", "meias-finais", "final", "vencer"];
  const ELITE_CUP_LEVEL_TIER = { "competitivo": 0, "meias-finais": 1, "final": 2, "vencer": 3 };
  const ELITE_CUP_OBJECTIVE_LABEL = {
    "competitivo": "Ser competitivo", "meias-finais": "Chegar às meias-finais",
    "final": "Chegar à final", "vencer": "Vencer a Elite Cup",
  };
  // Limiares de pontuação de expectativa (0-100) que definem o nível base do objetivo, antes do
  // ajuste do sorteio. Calibrados para que a generalidade dos 8 qualificados (clubes fortes,
  // por definição, já que só chegam aqui os 8 primeiros do Placard) se reparta pelos 4 níveis
  // em vez de se concentrar toda no mesmo.
  const ELITE_CUP_OBJECTIVE_THRESHOLDS = Object.freeze({ vencer: 78, final: 60, "meias-finais": 40 });
  // Diferença de pontuação de expectativa entre dois clubes (0-100) a partir da qual o sorteio
  // justifica um ajuste de 1 nível ao objetivo — para cima (adversário claramente mais fraco) ou
  // para baixo (adversário claramente mais forte). Usado também para atenuar a avaliação final
  // (perder contra quem é claramente mais forte pesa menos).
  const ELITE_CUP_DRAW_ADJUST_THRESHOLD = 18;
  // Impacto (delta aplicado a team.desempenhoRecente, o proxy mais próximo de "moral"/forma que
  // o jogo já tem) de cada resultado da avaliação — sempre pequeno face ao recálculo de fim de
  // época (que já reflete, isoladamente, ganhos de dezenas de pontos), como pede o roteiro
  // ("impacto reduzido", "nunca equivalente ao objetivo da Taça de Portugal").
  const ELITE_CUP_EVAL_IMPACT = Object.freeze({
    superado: 2, cumprido: .8, "falhado-uma-fase": -.6, "falhado-claramente": -1.6,
  });
  // Queda de disponibilidade (pontos, 0-100) entre a criação do objetivo e o momento da
  // eliminação a partir da qual se considera "lesões/castigos inesperados" e se atenua a
  // penalização (ver 11.4.5 do roteiro).
  const ELITE_CUP_AVAILABILITY_DROP_ATTENUATION = 20;

  function eliteCupMakeTie(a, b) {
    return { home: a, away: b, homeScore: 0, awayScore: 0, soWinner: null, played: false, date: null };
  }
  function eliteCupTieWinner(tie) {
    if (!tie.played) return null;
    if (tie.homeScore > tie.awayScore) return tie.home;
    if (tie.awayScore > tie.homeScore) return tie.away;
    if (tie.soWinner === "home") return tie.home;
    if (tie.soWinner === "away") return tie.away;
    return null;
  }
  // Sorteio dos quartos: pote 1 (lugares 1-4) cruza sempre com pote 2 (lugares 5-8) — nunca dois
  // clubes do mesmo pote entre si (secção 5 do roteiro). Extraída para função própria só para
  // ficar testável isoladamente (ver testEliteCupDrawCrossesPots, 12-arranque.js).
  function eliteCupDrawQuartos(pot1, pot2) {
    const p1 = shuffleArray(pot1), p2 = shuffleArray(pot2);
    return p1.map((id, i) => eliteCupMakeTie(id, p2[i]));
  }
  function eliteCupEditionConcluded() {
    const e = state.eliteCup && state.eliteCup.edicao;
    return !e || e.fase === "concluida";
  }

  // Datas-alvo da edição desta época: segunda-feira anterior aos quartos (guardada só como
  // referência, conforme o roteiro), sexta-feira quartos, sábado meias-finais, domingo final.
  // Correção (calendário sem saltos, pedido explícito do utilizador, 2026-09-14: "a elite cup é
  // jogada no final de setembro, sexta (quartos), sábado meias e domingo final"): a Elite Cup
  // passa da 3.ª semana de julho para a ÚLTIMA sexta/sábado/domingo de setembro — a época já
  // passa a começar a 1 de setembro (ver seasonStartDate, 01-nucleo.js) e o tempo corre sempre
  // dia a dia até lá (sem qualquer salto), por isso já não é preciso nenhuma "margem" antes da
  // Elite Cup como havia antes. lastWeekdayOfMonth (01-nucleo.js) devolve a última sexta-feira do
  // mês; addDays já existe (07b-taca-portugal.js).
  function eliteCupFaseDates(season) {
    const y = 2026 + (season - 1);
    const friday = lastWeekdayOfMonth(y, 8, 5); // setembro=8 (0-indexado), sexta=5
    return { monday: addDays(friday, -4), friday, saturday: addDays(friday, 1), sunday: addDays(friday, 2) };
  }
  function eliteCupAssignDatesForFase(edicao, fase) {
    if (!edicao.datas) edicao.datas = eliteCupFaseDates(edicao.epoca);
    const dateFor = { quartos: edicao.datas.friday, semifinal: edicao.datas.saturday, final: edicao.datas.sunday }[fase];
    // Correção (verificação pedida pelo utilizador): a janela de final de julho da Elite Cup foi
    // desenhada para nunca coincidir com nenhuma outra prova — mas passa a confirmar-se sempre,
    // com a mesma proteção genérica já usada por todas as restantes competições, em vez de confiar
    // só na intenção original de calendário. Chamada antes de atribuir a data aos próprios jogos.
    // Os clubes desta fase já são conhecidos neste momento — protege-se apenas a disponibilidade
    // real desses clubes (3.3 da auditoria externa), não o dia inteiro.
    avoidLeagueCollisionsOnDate(dateFor, "Elite Cup", (edicao.jogos[fase]||[]).flatMap(j=>[j.home,j.away]));
    (edicao.jogos[fase] || []).forEach(j => { j.date = new Date(dateFor); });
  }

  // Jogadores "disponíveis" para efeitos de profundidade/disponibilidade do plantel — inclui
  // guarda-redes (ao contrário de availablePlayersForSystemFit, pensada só para linhas de
  // sistema tático), pela mesma razão de fundo: não suspenso, condição mínima aceitável.
  function eliteCupAvailablePlayers(team) {
    return (team.players || []).filter(p => playerAvailableForMatch(p) && (p.condicao == null || p.condicao >= 25));
  }
  // Força atual do plantel: média de OVR dos melhores até 12 jogadores (dimensão típica de um
  // plantel de convocados nesta modalidade — ver ensureMinimumSquad/freeSquadSize) — não conta
  // só a reputação do clube, como o roteiro exige explicitamente (11.4.2).
  function eliteCupSquadStrength(team) {
    const overalls = (team.players || []).map(p => overall(p)).sort((a, b) => b - a);
    const top = overalls.slice(0, 12);
    return top.length ? top.reduce((s, v) => s + v, 0) / top.length : 0;
  }
  // Profundidade (capacidade de aguentar até 3 jogos em 3 dias consecutivos — sexta/sábado/
  // domingo) e disponibilidade (impacto real de lesões/castigos conhecidos) — duas dimensões
  // distintas do roteiro (11.4.2), a partir dos mesmos jogadores disponíveis.
  function eliteCupAvailabilityFactors(team) {
    const all = team.players || [];
    const available = eliteCupAvailablePlayers(team);
    const depthScore = clamp(available.length / 16 * 100, 0, 100);
    const totalQuality = all.reduce((s, p) => s + overall(p), 0) || 1;
    const availableQuality = available.reduce((s, p) => s + overall(p), 0);
    const availabilityScore = clamp(availableQuality / totalQuality * 100, 0, 100);
    return { depthScore, availabilityScore };
  }

  function eliteCupObjectiveLevelFromScore(score) {
    const t = ELITE_CUP_OBJECTIVE_THRESHOLDS;
    if (score >= t.vencer) return "vencer";
    if (score >= t.final) return "final";
    if (score >= t["meias-finais"]) return "meias-finais";
    return "competitivo";
  }

  // Fatores de expectativa dos 8 qualificados, calculados todos ao mesmo tempo (a normalização
  // de reputação/força de plantel é sempre "dentro do universo competitivo", ou seja, só entre
  // estes 8 clubes — 11.4.2 do roteiro — e não contra a generalidade do jogo).
  function computeEliteCupExpectationFactors(edicao) {
    const ids = edicao.participantes, raw = {};
    ids.forEach(id => {
      const team = state.teams[id];
      const rep = team.reputacaoPontos != null ? team.reputacaoPontos : normalizeClubReputation(team.reputacao, team);
      const squad = eliteCupSquadStrength(team);
      const form = clamp(team.desempenhoRecente != null ? team.desempenhoRecente : 50, 0, 100);
      const rank = edicao.ranking[id] || 8;
      const qualification = clamp((8 - rank) / 7 * 100, 0, 100);
      const { depthScore, availabilityScore } = eliteCupAvailabilityFactors(team);
      raw[id] = { rep, squad, form, qualification, depthScore, availabilityScore };
    });
    const repVals = ids.map(id => raw[id].rep), squadVals = ids.map(id => raw[id].squad);
    const repMin = Math.min(...repVals), repMax = Math.max(...repVals);
    const squadMin = Math.min(...squadVals), squadMax = Math.max(...squadVals);
    const norm = (v, min, max) => max > min ? clamp((v - min) / (max - min) * 100, 0, 100) : 50;
    const w = ELITE_CUP_OBJECTIVE_WEIGHTS, factors = {};
    ids.forEach(id => {
      const r = raw[id];
      const reputationScore = norm(r.rep, repMin, repMax);
      const currentSquadStrength = norm(r.squad, squadMin, squadMax);
      const recentFormScore = r.form, qualificationScore = r.qualification;
      const squadDepthScore = r.depthScore, availabilityScore = r.availabilityScore;
      const expectationScore = reputationScore * w.reputation + currentSquadStrength * w.squadStrength
        + recentFormScore * w.recentForm + qualificationScore * w.qualification
        + squadDepthScore * w.squadDepth + availabilityScore * w.availability;
      factors[id] = { reputationScore, currentSquadStrength, recentFormScore, qualificationScore, squadDepthScore, availabilityScore, expectationScore: roundDecimal(expectationScore) };
    });
    return factors;
  }

  // Objetivo base (antes do sorteio), um por qualificado — nunca depende só da reputação
  // histórica (princípio obrigatório do roteiro, 11.4).
  function eliteCupCreateBaseObjectives(edicao) {
    const factors = computeEliteCupExpectationFactors(edicao);
    edicao.objetivos = {};
    edicao.participantes.forEach(id => {
      const f = factors[id];
      edicao.objetivos[id] = {
        clubId: id, editionId: edicao.epoca, objectiveLevel: eliteCupObjectiveLevelFromScore(f.expectationScore),
        baseExpectationScore: f.expectationScore, factorSnapshot: { ...f },
        drawDifficulty: null, drawAdjustment: 0,
        createdAt: new Date(state.currentDate), lockedAt: null, communicated: false,
        evaluationStatus: "pendente", evaluationImpact: null, evaluatedAt: null,
      };
    });
  }
  // Ajuste pós-sorteio (11.4.3): compara a pontuação de expectativa contra o adversário dos
  // quartos — o único já conhecido no momento do sorteio — e ajusta no máximo 1 nível, nunca
  // mais. Determinístico (só depende das pontuações já guardadas) e feito uma única vez por
  // clube (idempotente via obj.lockedAt).
  function eliteCupApplyDrawAdjustment(edicao) {
    const LEVELS = ELITE_CUP_OBJECTIVE_LEVELS;
    (edicao.jogos.quartos || []).forEach(tie => {
      [[tie.home, tie.away], [tie.away, tie.home]].forEach(([me, opp]) => {
        const obj = edicao.objetivos[me];
        if (!obj || obj.lockedAt) return;
        const oppObj = edicao.objetivos[opp];
        const diff = roundDecimal((oppObj ? oppObj.baseExpectationScore : obj.baseExpectationScore) - obj.baseExpectationScore);
        let adjustment = 0;
        if (diff >= ELITE_CUP_DRAW_ADJUST_THRESHOLD) adjustment = -1; // adversário claramente mais forte
        else if (diff <= -ELITE_CUP_DRAW_ADJUST_THRESHOLD) adjustment = 1; // adversário claramente mais fraco
        const baseIdx = LEVELS.indexOf(obj.objectiveLevel);
        const newIdx = clamp(baseIdx + adjustment, 0, LEVELS.length - 1);
        obj.drawDifficulty = diff;
        obj.drawAdjustment = LEVELS[newIdx] === obj.objectiveLevel ? 0 : adjustment;
        obj.objectiveLevel = LEVELS[newIdx];
        obj.lockedAt = new Date(state.currentDate);
      });
    });
  }
  function eliteCupCommunicateObjectives(edicao) {
    // Correção (pedido do utilizador, 2026-09-17: "o email que diz que cada direcção definiu os
    // objectivos para a elite cup deve ser eliminado"): a notícia genérica sobre os OUTROS
    // clubes qualificados ("a direção de cada um dos N qualificados definiu...") não interessa
    // ao utilizador — é só ruído sobre decisões internas de clubes de IA. A marcação
    // obj.communicated mantém-se (idempotência: eliteCupEvaluateObjective e este próprio método
    // continuam a precisar dela), só deixou de haver notícia para ela. O email do PRÓPRIO
    // objetivo do clube do utilizador mantém-se — esse é diretamente relevante.
    edicao.participantes.forEach(id => {
      const obj = edicao.objetivos[id];
      if (!obj || obj.communicated) return;
      obj.communicated = true;
    });
    const meuObj = edicao.objetivos[state.userTeamId];
    if (meuObj) {
      pushNews(state.currentDate, `A direção do ${teamLinkHtml(state.userTeamId)} traçou como objetivo para a Elite Cup: "${ELITE_CUP_OBJECTIVE_LABEL[meuObj.objectiveLevel]}".`, "sistema", "Objetivo da direção para a Elite Cup");
    }
  }
  // Avaliação (11.4.4/11.4.5) — chamada uma única vez por clube, no momento em que fica
  // eliminado (ou sagrado campeão). Idempotente (evaluationStatus), nunca reescreve o objetivo
  // histórico, e nunca pode, isoladamente, despedir o treinador — não existe, de resto, nenhum
  // mecanismo de despedimento de treinador ligado a resultados desportivos em todo o jogo (só
  // insolvência financeira termina uma carreira, ver state.gameOver em 04-financas.js), pelo que
  // esta condição fica automaticamente satisfeita.
  function eliteCupEvaluateObjective(clubId, achievedTier, context) {
    const edicao = state.eliteCup && state.eliteCup.edicao;
    const obj = edicao && edicao.objetivos && edicao.objetivos[clubId];
    if (!obj || obj.evaluationStatus === "avaliado") return;
    context = context || {};
    const requiredTier = ELITE_CUP_LEVEL_TIER[obj.objectiveLevel];
    const diff = achievedTier - requiredTier;
    let resultado = diff >= 1 ? "superado" : diff === 0 ? "cumprido" : diff === -1 ? "falhado-uma-fase" : "falhado-claramente";
    let delta = ELITE_CUP_EVAL_IMPACT[resultado];
    let atenuada = false;
    if (delta < 0) {
      // Proteção: derrota em grandes penalidades conta como resultado equilibrado, nunca a
      // penalização mais dura.
      if (context.viaGrandesPenalidades && resultado === "falhado-claramente") {
        resultado = "falhado-uma-fase"; delta = ELITE_CUP_EVAL_IMPACT[resultado]; atenuada = true;
      }
      // Proteção: perder contra um adversário claramente mais forte pesa menos do que perder
      // contra um claramente mais fraco.
      if (context.oppScore != null && (context.oppScore - obj.baseExpectationScore) >= ELITE_CUP_DRAW_ADJUST_THRESHOLD) {
        delta *= .5; atenuada = true;
      }
      // Proteção: lesões/castigos inesperados depois de o objetivo ter sido definido atenuam a
      // penalização, sem reescrever o objetivo (obj.objectiveLevel não muda).
      const team = state.teams[clubId];
      if (team && obj.factorSnapshot) {
        const agora = eliteCupAvailabilityFactors(team).availabilityScore;
        if ((obj.factorSnapshot.availabilityScore - agora) >= ELITE_CUP_AVAILABILITY_DROP_ATTENUATION) { delta *= .5; atenuada = true; }
      }
    }
    obj.evaluationStatus = "avaliado";
    obj.evaluationImpact = { resultado, moralDelta: roundDecimal(delta), atenuada, viaGrandesPenalidades: !!context.viaGrandesPenalidades };
    obj.evaluatedAt = new Date(state.currentDate);
    const team = state.teams[clubId];
    if (team && delta !== 0) team.desempenhoRecente = clamp(roundDecimal(team.desempenhoRecente + delta), 5, 99);
  }

  function eliteCupQualifiersFromSummary(summary) {
    if (summary && Array.isArray(summary.placardTop8) && summary.placardTop8.length === 8) return summary.placardTop8.slice();
    return null;
  }
  function eliteCupPublishUserDrawNews(fase) {
    const edicao = state.eliteCup.edicao;
    const tie = (edicao.jogos[fase] || []).find(j => j.home === state.userTeamId || j.away === state.userTeamId);
    if (!tie) return;
    const opp = tie.home === state.userTeamId ? tie.away : tie.home;
    const nome = ELITE_CUP_FASE_LABEL[fase].replace("Elite Cup — ", "");
    pushNews(state.currentDate, `${myTeam().name} vai defrontar ${teamLinkHtml(opp)}, em campo neutro, nos ${nome} da Elite Cup ${edicao.seasonLabel}.`, "sistema", `Elite Cup: ${myTeam().name} defronta ${state.teams[opp].name}`);
  }

  // Início de época/carreira: monta a edição desta época — a partir de chooseClub()
  // (initialEditionOverride, 1.ª carreira) ou de finalizeNewSeason() (a partir do top 8 do
  // Campeonato Placard da época que terminou, capturado em applyPromotionAndRelegation antes de
  // promoções/despromoções serem aplicadas — ver placardTop8 em 07-playoff.js).
  function initEliteCup(options) {
    options = options || {};
    if (!state.eliteCup || typeof state.eliteCup !== "object") state.eliteCup = { historico: [], edicao: null };
    if (!Array.isArray(state.eliteCup.historico)) state.eliteCup.historico = [];
    // Idempotência (mesmo padrão da Taça/Supertaça): nunca recriar a edição desta mesma época.
    if (state.eliteCup.edicao && state.eliteCup.edicao.epoca === state.season) return;
    if (state.eliteCup.historico.some(e => e.epoca === state.season)) return;
    let ranking;
    if (options.initialEditionOverride) {
      ranking = ELITE_CUP_INITIAL_RANKING.slice();
    } else {
      ranking = eliteCupQualifiersFromSummary(options.summary || state.pendingSeasonSummary || state.lastSeasonSummary || {});
    }
    if (!ranking || ranking.length !== 8 || ranking.some(id => !state.teams[id])) {
      console.error("Elite Cup: qualificação inexistente ou inválida — edição não gerada.", ranking);
      state.eliteCup.edicao = null;
      return;
    }
    const rankingMap = {};
    ranking.forEach((id, i) => { rankingMap[id] = i + 1; });
    const pot1 = ranking.slice(0, 4), pot2 = ranking.slice(4, 8);
    const edicao = {
      epoca: state.season, seasonLabel: seasonLabel(state.season), fase: "quartos",
      participantes: ranking.slice(), pot1, pot2, ranking: rankingMap,
      jogos: { quartos: [], semifinal: [], final: [] },
      campeao: null, runnerUp: null, premiosAtribuidos: false, objetivos: {},
    };
    eliteCupCreateBaseObjectives(edicao);
    edicao.jogos.quartos = eliteCupDrawQuartos(pot1, pot2);
    eliteCupApplyDrawAdjustment(edicao);
    state.eliteCup.edicao = edicao;
    eliteCupAssignDatesForFase(edicao, "quartos");
    eliteCupCommunicateObjectives(edicao);
    pushNews(state.currentDate, `Sorteio da Elite Cup ${edicao.seasonLabel} realizado — quartos de final: ${edicao.jogos.quartos.map(j => `${teamLinkHtml(j.home)} vs ${teamLinkHtml(j.away)}`).join("; ")}.`, "sistema", "Elite Cup — Sorteio dos Quartos de Final", {autoAdvanceStop:true});
    eliteCupPublishUserDrawNews("quartos");
  }

  function eliteCupAwardChampion(edicao, campeaoId, runnerUpId) {
    const campeaoTeam = state.teams[campeaoId], runnerUpTeam = state.teams[runnerUpId];
    edicao.campeao = campeaoId; edicao.runnerUp = runnerUpId;
    if (campeaoTeam) {
      awardClubTitle(campeaoId, "elite-cup", `Elite Cup ${edicao.seasonLabel}`);
      campeaoTeam.reputacaoPontos = clamp((campeaoTeam.reputacaoPontos != null ? campeaoTeam.reputacaoPontos : normalizeClubReputation(campeaoTeam.reputacao, campeaoTeam)) + ELITE_CUP_PRESTIGE_WINNER, 5, 99);
      campeaoTeam.reputacao = reputationFromPoints(campeaoTeam.reputacaoPontos);
      addFinanceMovement(campeaoTeam, "receita", "Prémio de competição", `Elite Cup ${edicao.seasonLabel} — vencedor`, ELITE_CUP_PRIZE_WINNER, state.currentDate);
    }
    if (runnerUpTeam) addFinanceMovement(runnerUpTeam, "receita", "Prémio de competição", `Elite Cup ${edicao.seasonLabel} — finalista`, ELITE_CUP_PRIZE_RUNNERUP, state.currentDate);
    (edicao.jogos.semifinal || []).forEach(j => {
      const loserId = eliteCupTieWinner(j) === j.home ? j.away : j.home;
      const team = state.teams[loserId];
      if (team) addFinanceMovement(team, "receita", "Prémio de competição", `Elite Cup ${edicao.seasonLabel} — meia-final`, ELITE_CUP_PRIZE_SEMIFINALIST, state.currentDate);
    });
    edicao.premiosAtribuidos = true;
    pushNews(state.currentDate, `🏆 ${teamLinkHtml(campeaoId)} venceu a Elite Cup ${edicao.seasonLabel}!`, "sistema", "Elite Cup — Campeão", {autoAdvanceStop:true});
  }
  function eliteCupCheckFaseComplete(edicao, fase) {
    const jogos = edicao.jogos[fase] || [];
    if (!jogos.length || !jogos.every(j => j.played)) return;
    if (fase === "quartos") {
      const winners = shuffleArray(jogos.map(eliteCupTieWinner));
      edicao.jogos.semifinal = [eliteCupMakeTie(winners[0], winners[1]), eliteCupMakeTie(winners[2], winners[3])];
      edicao.fase = "semifinal";
      eliteCupAssignDatesForFase(edicao, "semifinal");
      pushNews(state.currentDate, `Meias-finais da Elite Cup ${edicao.seasonLabel} definidas: ${teamLinkHtml(winners[0])} vs ${teamLinkHtml(winners[1])}; ${teamLinkHtml(winners[2])} vs ${teamLinkHtml(winners[3])}.`, "sistema", "Elite Cup — Meias-Finais", {autoAdvanceStop:true});
      eliteCupPublishUserDrawNews("semifinal");
    } else if (fase === "semifinal") {
      const winners = jogos.map(eliteCupTieWinner);
      edicao.jogos.final = [eliteCupMakeTie(winners[0], winners[1])];
      edicao.fase = "final";
      eliteCupAssignDatesForFase(edicao, "final");
      pushNews(state.currentDate, `Final da Elite Cup ${edicao.seasonLabel} definida: ${teamLinkHtml(winners[0])} vs ${teamLinkHtml(winners[1])}.`, "sistema", "Elite Cup — Final", {autoAdvanceStop:true});
      eliteCupPublishUserDrawNews("final");
    }
  }
  function eliteCupRecordTieResult(fase, idx, hs, as, soWinner) {
    const edicao = state.eliteCup && state.eliteCup.edicao;
    const tie = edicao && edicao.jogos[fase] && edicao.jogos[fase][idx];
    if (!tie || tie.played) return;
    tie.played = true; tie.homeScore = hs; tie.awayScore = as; tie.soWinner = soWinner || null;
    const winner = eliteCupTieWinner(tie), loser = winner === tie.home ? tie.away : tie.home;
    if (!winner) {
      console.error("Elite Cup: eliminatória terminou sem vencedor definido.", tie);
      return;
    }
    const loserObj = edicao.objetivos[winner];
    eliteCupEvaluateObjective(loser, ELITE_CUP_FASE_ELIMINATION_TIER[fase], { viaGrandesPenalidades: !!soWinner, oppScore: loserObj ? loserObj.baseExpectationScore : null });
    const marcador = `${hs}-${as}${soWinner ? " (g.p.)" : ""}`;
    // Correção (pedido do utilizador, 2026-09-17: "não quero notícias individuais de resultados
    // da elite cup ou WSE ou outra competição"): resultado de um confronto entre dois clubes de
    // IA não interessa ao utilizador — só publica quando um dos dois é o próprio clube dele (a
    // notícia dedicada de "passa de fase"/"eliminado", logo a seguir, já cobre esse caso).
    if(winner===state.userTeamId || loser===state.userTeamId){
      pushNews(state.currentDate, `${teamLinkHtml(winner)} elimina ${teamLinkHtml(loser)} (${marcador}) na Elite Cup ${edicao.seasonLabel}.`, "jogo", `${ELITE_CUP_FASE_LABEL[fase]} — Resultado`);
    }
    // Correção (verificação pedida pelo utilizador: notícia sempre que a equipa do utilizador
    // passa de fase ou sai da competição) — mesmo padrão já usado na Taça de Portugal/Copa del
    // Rey/Coppa Italia/Supercopa de España, em vez de deixar o utilizador depender só da
    // mensagem genérica acima (que nomeia sempre os dois clubes, mas nunca em tom pessoal).
    const ELITE_CUP_FASE_ARTIGO = { quartos: "os Quartos de Final", semifinal: "as Meias-Finais", final: "a Final" };
    const ELITE_CUP_FASE_EM = { quartos: "nos Quartos de Final", semifinal: "nas Meias-Finais", final: "na Final" };
    if (winner === state.userTeamId && fase !== "final") {
      pushNews(state.currentDate, `${teamLinkHtml(winner)} passa ${ELITE_CUP_FASE_ARTIGO[fase] || fase} da Elite Cup ${edicao.seasonLabel}, após vencer ${teamLinkHtml(loser)} por ${marcador}.`, "sistema", `${myTeam().name} avança na Elite Cup`, {autoAdvanceStop:true});
    } else if (loser === state.userTeamId) {
      pushNews(state.currentDate, `${teamLinkHtml(loser)} foi eliminado da Elite Cup ${edicao.seasonLabel} ${ELITE_CUP_FASE_EM[fase] || fase}, após perder com ${teamLinkHtml(winner)} por ${marcador}.`, "sistema", `${myTeam().name} eliminado da Elite Cup`, {autoAdvanceStop:true});
    }
    if (fase === "final") {
      const winnerOppObj = edicao.objetivos[loser];
      eliteCupEvaluateObjective(winner, 3, { viaGrandesPenalidades: false, oppScore: winnerOppObj ? winnerOppObj.baseExpectationScore : null });
      eliteCupAwardChampion(edicao, winner, loser);
      edicao.fase = "concluida";
      if (!state.eliteCup.historico.some(e => e.epoca === edicao.epoca)) state.eliteCup.historico.push({ ...edicao });
      // Dispara aqui mesmo (e só aqui — ponto único, evita disparar duas vezes) a sequência que
      // ficou pendente (ver initEliteCup/eliteCupRunPostSequence): processEliteCupForCurrentDate
      // não pode fazer esta deteção de forma fiável, porque a sua própria guarda de entrada
      // (edicao.fase==="concluida") impede-a de voltar a correr quando é chamada de novo logo a
      // seguir a esta eliminatória (seja pelo "continue" do seu próprio ciclo, seja pelo
      // finalizeMatchBookkeeping, quando é o próprio utilizador a decidir a final).
      eliteCupRunPostSequence();
      return;
    }
    eliteCupCheckFaseComplete(edicao, fase);
  }

  // Processamento — chamado a partir de initEliteCup (arranque da edição) e de dentro de
  // finalizeMatchBookkeeping depois de resolvido o jogo do utilizador (para continuar a
  // resolver o resto da prova). Resolve de imediato todas as eliminatórias IA-IA da fase atual
  // (mesmo padrão do "while(true)" da Taça de Portugal, só que sem depender de uma data
  // específica — ver nota de arquitetura no topo do ficheiro); pára assim que encontra o jogo do
  // próprio utilizador. A sequência pendente (eliteCupRunPostSequence) é disparada a partir de
  // eliteCupRecordTieResult, no momento exato em que a final é decidida — não aqui, para não
  // depender de sermos chamados de novo depois de a prova já estar "concluida".
  function processEliteCupForCurrentDate() {
    const edicao = state.eliteCup && state.eliteCup.edicao;
    if (!edicao || edicao.fase === "concluida") return false;
    let processedAny = false;
    while (true) {
      const jogos = edicao.jogos[edicao.fase] || [];
      const idx = jogos.findIndex(j => !j.played);
      if (idx < 0) break;
      // Correção (bug real, reportado pelo utilizador: "quando começo, com o Tojal por exemplo,
      // a Elite já está jogada!"): a prova resolvia-se sempre de imediato, nunca respeitando as
      // datas reais de cada fase (sexta/sábado/domingo) — currentDate era só empurrado a reboque
      // da resolução, nunca o contrário. Para um clube que NÃO é participante (cuja prova inteira
      // se resolve numa só chamada síncrona, sem qualquer pausa interativa), isto significava que,
      // mal a época começava, a Elite Cup já estava toda jogada — impossível de acompanhar, mesmo
      // como espectador. Passa a exigir que o calendário já tenha mesmo chegado à data desta fase
      // antes de resolver seja o que for; caso contrário, pára aqui e devolve o controlo ao ciclo
      // normal de avanço de dia (ver processPhaseFiveFinalsForCurrentDate, em 07-playoff.js,
      // chamado a cada clique em "Continuar"), que volta a chamar esta função no dia seguinte.
      // Aplica-se por igual às eliminatórias IA-IA e ao jogo do próprio utilizador. A data de
      // arranque da carreira/época já está sempre 1 semana antes dos quartos de final (ver
      // chooseClub, 05-ui-navegacao.js, e beginDefeso, 08-evolucao-jogadores.js), por isso a
      // prova acaba sempre por chegar a horas, uns dias depois de a época "começar".
      const faseDateKey = { quartos: "friday", semifinal: "saturday", final: "sunday" }[edicao.fase];
      const faseDate = edicao.datas && faseDateKey ? edicao.datas[faseDateKey] : null;
      if (faseDate && state.currentDate && faseDate.getTime() > state.currentDate.getTime()) {
        return processedAny;
      }
      const tie = jogos[idx];
      const involvesUser = tie.home === state.userTeamId || tie.away === state.userTeamId;
      if (!involvesUser) {
        const res = simulateMatchToCompletion(tie.home, tie.away, true, true, "elite-cup"); // isPlayoff / neutralVenue: sempre, na Elite Cup
        eliteCupRecordTieResult(edicao.fase, idx, res.home, res.away, res.soWinner);
        processedAny = true;
        if (edicao.fase === "concluida") break;
        continue;
      }
      // Correção (bug real, reportado pelo utilizador: "não fiz muitos dos jogos porque são jogos
      // no mesmo dia"): faltava aqui a mesma guarda de vaga única (matchDayReady/pendingFixture)
      // que a Taça de Portugal, a Supertaça, os Copas nacionais e a Europa já respeitam — esta
      // função reivindicava sempre o dia para o jogo do utilizador na Elite Cup, mesmo quando
      // outra prova (tipicamente a própria liga) já o tinha reivindicado primeiro nesta mesma
      // passagem de processPhaseFiveFinalsForCurrentDate. Isso apagava silenciosamente o jogo já
      // agendado (pendingFixture era substituído), e esse jogo nunca mais era recuperado: a
      // jornada da liga ficava com essa eliminatória por marcar para sempre (o evento de agenda
      // correspondente só é dado como processado quando o próprio jogo de liga é mesmo jogado —
      // ver maybeAdvanceRound), o que também impedia state.currentRound de alguma vez chegar ao
      // fim da fase regular e arrancar o playoff, mesmo terminando em 1º lugar. Passa a esperar,
      // tal como as restantes provas: se a vaga já estiver ocupada hoje, esta eliminatória fica
      // por jogar até à próxima chamada com a vaga livre (a verificação de data no topo do ciclo
      // já trata "chegou ou já passou", por isso nunca se perde).
      if(state.matchDayReady) break;
      const oppId = tie.home === state.userTeamId ? tie.away : tie.home;
      state.pendingProvisional = { mine: ensureMinimumSquad(myTeam()), opp: ensureMinimumSquad(state.teams[oppId]) };
      state.pendingFixture = tie; state.pendingEliteCupFase = edicao.fase; state.pendingEliteCupIndex = idx;
      state.pendingSuspensionServing = { home: getSuspendedIds(tie.home), away: getSuspendedIds(tie.away) };
      generatePreGameReport(tie, ELITE_CUP_FASE_LABEL[edicao.fase], null);
      state.matchDayReady = true;
      return true;
    }
    return processedAny;
  }
  // O que fazer a seguir, uma vez a Elite Cup mesmo concluída — decidido em initEliteCup
  // consoante quem a chamou (ver chooseClub em 05-ui-navegacao.js / finalizeNewSeason em
  // 08-evolucao-jogadores.js), e guardado em state.eliteCupPostSequence para sobreviver a um
  // save/load feito a meio da prova (ver applySaveObjectUnchecked em 11-guardar-carregar.js).
  function eliteCupRunPostSequence() {
    // Correção: a resolução comprimida nunca avança state.currentDate ao longo da prova (as
    // datas de cada fase — sexta/sábado/domingo — ficam só registadas para histórico/interface,
    // como documentado no topo do ficheiro). Isso deixava, até aqui, currentDate parado no dia
    // de arranque da carreira/época (ex.: 15 de julho) mesmo depois de notícias e resultados já
    // datados de vários dias depois (ex.: final a 20 de julho) — a pré-época seguinte arrancava
    // com a sensação de "viajar no tempo para trás", como se a Elite Cup tivesse acontecido
    // antes de a carreira sequer começar. Avança currentDate para a data da final (nunca para
    // trás) antes de prosseguir, para o calendário ficar coerente com o que já foi mostrado.
    const edicao = state.eliteCup && state.eliteCup.edicao;
    const finalDate = edicao && edicao.datas && edicao.datas.sunday;
    if (finalDate && state.currentDate && finalDate.getTime() > state.currentDate.getTime()) {
      state.currentDate = new Date(finalDate);
    }
    const seq = state.eliteCupPostSequence;
    state.eliteCupPostSequence = null;
    // "preSeasonDefeso" mantém-se só para compatibilidade com saves antigos, gravados a meio da
    // Elite Cup antes desta correção (a pré-época de mercado abria DEPOIS da prova terminar, não
    // antes) — nenhuma carreira nova volta a gerar este valor, ver chooseClub em
    // 05-ui-navegacao.js. Carreiras novas usam "preSeasonLeagueStart": a janela curta de mercado
    // já foi mostrada ANTES da Elite Cup arrancar, por isso agora avança-se direto para a 1.ª
    // jornada do campeonato (finalizePreSeasonLeagueStart), sem reabrir o mercado.
    if (seq === "preSeasonDefeso") startPreSeasonDefeso();
    else if (seq === "preSeasonLeagueStart") finalizePreSeasonLeagueStart();
    else if (seq === "newSeasonTail") finalizeNewSeasonTail(state.pendingSeasonSummary || {});
  }

  // Ré-hidratação de datas ao carregar um save (ver 11-guardar-carregar.js) — mesmo padrão já
  // usado para tacaPortugal/supertaca.
  function eliteCupDeserializeEdition(e) {
    if (!e) return null;
    const dedate = v => v ? new Date(v) : null;
    const jogos = {};
    Object.keys(e.jogos || {}).forEach(fase => { jogos[fase] = (e.jogos[fase] || []).map(j => ({ ...j, date: dedate(j.date) })); });
    const objetivos = {};
    Object.keys(e.objetivos || {}).forEach(id => {
      const o = e.objetivos[id];
      objetivos[id] = { ...o, createdAt: dedate(o.createdAt), lockedAt: dedate(o.lockedAt), evaluatedAt: dedate(o.evaluatedAt) };
    });
    return {
      ...e, jogos, objetivos,
      datas: e.datas ? { monday: dedate(e.datas.monday), friday: dedate(e.datas.friday), saturday: dedate(e.datas.saturday), sunday: dedate(e.datas.sunday) } : null,
    };
  }
  function eliteCupSerializeEdition(e) {
    if (!e) return null;
    const iso = v => v ? new Date(v).toISOString() : null;
    const jogos = {};
    Object.keys(e.jogos || {}).forEach(fase => { jogos[fase] = (e.jogos[fase] || []).map(j => ({ ...j, date: iso(j.date) })); });
    const objetivos = {};
    Object.keys(e.objetivos || {}).forEach(id => {
      const o = e.objetivos[id];
      objetivos[id] = { ...o, createdAt: iso(o.createdAt), lockedAt: iso(o.lockedAt), evaluatedAt: iso(o.evaluatedAt) };
    });
    return {
      ...e, jogos, objetivos,
      datas: e.datas ? { monday: iso(e.datas.monday), friday: iso(e.datas.friday), saturday: iso(e.datas.saturday), sunday: iso(e.datas.sunday) } : null,
    };
  }
